const express = require('express');
const router = express.Router();
const { pool } = require('../config/db');
const { authenticateToken } = require('../middleware/auth');

// GET /api/settings
router.get('/', authenticateToken, async (req, res) => {
  try {
    const [rows] = await pool.execute('SELECT * FROM user_settings WHERE user_id = ?', [req.user.id]);
    if (rows.length === 0) {
      await pool.execute('INSERT INTO user_settings (user_id) VALUES (?)', [req.user.id]);
      const [newRows] = await pool.execute('SELECT * FROM user_settings WHERE user_id = ?', [req.user.id]);
      return res.json({ settings: newRows[0] });
    }
    res.json({ settings: rows[0] });
  } catch (err) {
    res.status(500).json({ error: 'Failed to fetch settings' });
  }
});

// PUT /api/settings
router.put('/', authenticateToken, async (req, res) => {
  const { theme, font_size, notifications_enabled, auto_save_interval, public_profile } = req.body;
  try {
    await pool.execute(
      `INSERT INTO user_settings (user_id, theme, font_size, notifications_enabled, auto_save_interval, public_profile)
       VALUES (?,?,?,?,?,?) ON DUPLICATE KEY UPDATE
       theme=VALUES(theme), font_size=VALUES(font_size),
       notifications_enabled=VALUES(notifications_enabled),
       auto_save_interval=VALUES(auto_save_interval),
       public_profile=VALUES(public_profile)`,
      [req.user.id, theme||'vintage-paper', font_size||'medium',
       notifications_enabled!==undefined?notifications_enabled:true,
       auto_save_interval||30, public_profile||false]
    );
    if (theme) await pool.execute('UPDATE users SET theme=? WHERE id=?', [theme, req.user.id]);
    res.json({ message: 'Settings saved' });
  } catch (err) {
    res.status(500).json({ error: 'Failed to save settings' });
  }
});

// GET /api/settings/themes
router.get('/themes', authenticateToken, async (req, res) => {
  try {
    const [themes] = await pool.execute('SELECT * FROM themes ORDER BY is_default DESC');
    res.json({ themes });
  } catch (err) {
    res.status(500).json({ error: 'Failed to fetch themes' });
  }
});

module.exports = router;
