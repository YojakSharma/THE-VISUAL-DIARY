const express = require('express');
const router  = express.Router();
const { pool } = require('../config/db');
const { authenticateToken } = require('../middleware/auth');

// ─────────────────────────────────────────────────────────────
// GET /api/entries
//
// BUG-02 FIX: pool.execute() → pool.query() for this dynamic
//   query. pool.execute() caches prepared statements and can
//   mishandle LIMIT/OFFSET integer params on some mysql2 builds
//   on Windows. pool.query() uses client-side escaping and
//   handles dynamic SQL + LIMIT/OFFSET safely.
//
// BUG-06 FIX: COUNT query now uses the same WHERE filters so
//   the "X memories" total is always correct.
// ─────────────────────────────────────────────────────────────
router.get('/', authenticateToken, async (req, res) => {
  const { page = 1, limit = 10, mood, search, favorite } = req.query;
  const pageNum   = Math.max(1, parseInt(page,  10) || 1);
  const limitNum  = Math.max(1, parseInt(limit, 10) || 10);
  const offsetNum = (pageNum - 1) * limitNum;

  try {
    let where  = 'WHERE e.user_id = ?';
    const params = [req.user.id];

    if (mood)                { where += ' AND e.mood = ?';                            params.push(mood); }
    if (favorite === 'true') { where += ' AND e.is_favorite = 1'; }
    if (search)              { where += ' AND (e.title LIKE ? OR e.content LIKE ?)';  params.push(`%${search}%`, `%${search}%`); }

    // pool.query() — safe for dynamic SQL with LIMIT/OFFSET
    const mainSQL = `
      SELECT e.*,
        (SELECT GROUP_CONCAT(tag_name) FROM tags WHERE entry_id = e.id) AS tags,
        (SELECT filename FROM uploaded_images WHERE entry_id = e.id LIMIT 1) AS cover_image
      FROM journal_entries e
      ${where}
      ORDER BY e.entry_date DESC, e.created_at DESC
      LIMIT ${limitNum} OFFSET ${offsetNum}`;

    const [entries] = await pool.query(mainSQL, params);

    // COUNT with same filters
    const countSQL = `SELECT COUNT(*) AS total FROM journal_entries e ${where}`;
    const [[countRow]] = await pool.query(countSQL, params);

    res.json({
      entries,
      total:      countRow.total,
      page:       pageNum,
      totalPages: Math.ceil(countRow.total / limitNum),
    });
  } catch (err) {
    console.error('GET /api/entries error:', err);
    res.status(500).json({ error: 'Failed to fetch entries' });
  }
});

// GET /api/entries/stats
router.get('/stats', authenticateToken, async (req, res) => {
  try {
    const uid = req.user.id;

    const [[entryCount]] = await pool.execute(
      'SELECT COUNT(*) AS total FROM journal_entries WHERE user_id = ?', [uid]);
    const [[wordCount]] = await pool.execute(
      'SELECT COALESCE(SUM(word_count), 0) AS total FROM journal_entries WHERE user_id = ?', [uid]);
    const [moodData] = await pool.execute(
      `SELECT mood, COUNT(*) AS count FROM journal_entries
       WHERE user_id = ? AND mood IS NOT NULL
       GROUP BY mood ORDER BY count DESC LIMIT 5`, [uid]);
    const [dates] = await pool.execute(
      'SELECT DISTINCT DATE(entry_date) AS d FROM journal_entries WHERE user_id = ? ORDER BY d DESC', [uid]);

    let streak = 0;
    if (dates.length > 0) {
      const today = new Date(); today.setHours(0,0,0,0);
      let check = new Date(today);
      for (let i = 0; i < dates.length; i++) {
        const d = new Date(dates[i].d); d.setHours(0,0,0,0);
        const diff = Math.round((check - d) / 86400000);
        if (diff === 0 || diff === 1) { streak++; check = d; } else break;
      }
    }

    const [cats] = await pool.execute(
      'SELECT DISTINCT mood FROM journal_entries WHERE user_id = ? AND mood IS NOT NULL', [uid]);

    res.json({ totalEntries: entryCount.total, totalWords: wordCount.total, streak, categories: cats.length, topMoods: moodData });
  } catch (err) {
    console.error('GET /api/entries/stats error:', err);
    res.status(500).json({ error: 'Failed to fetch stats' });
  }
});

// GET /api/entries/calendar
router.get('/calendar', authenticateToken, async (req, res) => {
  const y = parseInt(req.query.year,  10) || new Date().getFullYear();
  const m = parseInt(req.query.month, 10) || (new Date().getMonth() + 1);
  try {
    const [entries] = await pool.execute(
      `SELECT id, title, entry_date, mood, is_favorite
         FROM journal_entries
        WHERE user_id = ? AND YEAR(entry_date) = ? AND MONTH(entry_date) = ?
        ORDER BY entry_date ASC`,
      [req.user.id, y, m]);
    res.json({ entries });
  } catch (err) {
    console.error('GET /api/entries/calendar error:', err);
    res.status(500).json({ error: 'Failed to fetch calendar data' });
  }
});

// GET /api/entries/:id
router.get('/:id', authenticateToken, async (req, res) => {
  try {
    const [rows] = await pool.execute(
      'SELECT * FROM journal_entries WHERE id = ? AND user_id = ?',
      [req.params.id, req.user.id]);
    if (rows.length === 0) return res.status(404).json({ error: 'Entry not found' });

    const [tags]   = await pool.execute('SELECT tag_name FROM tags WHERE entry_id = ?', [req.params.id]);
    const [images] = await pool.execute('SELECT * FROM uploaded_images WHERE entry_id = ?', [req.params.id]);

    res.json({ entry: { ...rows[0], tags: tags.map(t => t.tag_name), images } });
  } catch (err) {
    console.error('GET /api/entries/:id error:', err);
    res.status(500).json({ error: 'Failed to fetch entry' });
  }
});

// POST /api/entries
router.post('/', authenticateToken, async (req, res) => {
  const { title, content, mood, is_draft, entry_date, tags } = req.body;
  const dateValue = entry_date || new Date().toISOString().split('T')[0];
  const wordCount = content ? content.trim().split(/\s+/).filter(Boolean).length : 0;

  try {
    const [result] = await pool.execute(
      `INSERT INTO journal_entries (user_id, title, content, mood, is_draft, entry_date, word_count)
       VALUES (?, ?, ?, ?, ?, ?, ?)`,
      [req.user.id, title || 'Untitled', content || '', mood || null, is_draft ? 1 : 0, dateValue, wordCount]);

    const entryId = result.insertId;

    if (Array.isArray(tags)) {
      for (const tag of tags) {
        if (tag && tag.trim()) {
          await pool.execute('INSERT INTO tags (user_id, entry_id, tag_name) VALUES (?, ?, ?)',
            [req.user.id, entryId, tag.trim()]);
        }
      }
    }

    if (mood) {
      await pool.execute('INSERT INTO moods (user_id, entry_id, mood_label, mood_date) VALUES (?, ?, ?, ?)',
        [req.user.id, entryId, mood, dateValue]);
    }

    res.status(201).json({ message: 'Entry created', entryId });
  } catch (err) {
    console.error('POST /api/entries error:', err);
    res.status(500).json({ error: 'Failed to create entry' });
  }
});

// PUT /api/entries/:id
router.put('/:id', authenticateToken, async (req, res) => {
  const { title, content, mood, is_draft, is_favorite, entry_date, tags } = req.body;
  try {
    const [existing] = await pool.execute(
      'SELECT id FROM journal_entries WHERE id = ? AND user_id = ?',
      [req.params.id, req.user.id]);
    if (existing.length === 0) return res.status(404).json({ error: 'Entry not found' });

    const dateValue = entry_date || new Date().toISOString().split('T')[0];
    const wordCount = content ? content.trim().split(/\s+/).filter(Boolean).length : 0;

    await pool.execute(
      `UPDATE journal_entries
          SET title=?, content=?, mood=?, is_draft=?, is_favorite=?,
              entry_date=?, word_count=?, updated_at=NOW()
        WHERE id=? AND user_id=?`,
      [title || 'Untitled', content || '', mood || null,
       is_draft ? 1 : 0, is_favorite ? 1 : 0,
       dateValue, wordCount, req.params.id, req.user.id]);

    if (Array.isArray(tags)) {
      await pool.execute('DELETE FROM tags WHERE entry_id = ?', [req.params.id]);
      for (const tag of tags) {
        if (tag && tag.trim()) {
          await pool.execute('INSERT INTO tags (user_id, entry_id, tag_name) VALUES (?, ?, ?)',
            [req.user.id, req.params.id, tag.trim()]);
        }
      }
    }

    res.json({ message: 'Entry updated' });
  } catch (err) {
    console.error('PUT /api/entries/:id error:', err);
    res.status(500).json({ error: 'Failed to update entry' });
  }
});

// ─────────────────────────────────────────────────────────────
// PATCH /api/entries/:id/favorite
//
// BUG-07 FIX: this endpoint was missing entirely. Now enables
//   one-click favorite toggle from the entries list without
//   needing to open the full editor.
// ─────────────────────────────────────────────────────────────
router.patch('/:id/favorite', authenticateToken, async (req, res) => {
  try {
    const [rows] = await pool.execute(
      'SELECT is_favorite FROM journal_entries WHERE id = ? AND user_id = ?',
      [req.params.id, req.user.id]);
    if (rows.length === 0) return res.status(404).json({ error: 'Entry not found' });

    const newValue = rows[0].is_favorite ? 0 : 1;
    await pool.execute(
      'UPDATE journal_entries SET is_favorite=?, updated_at=NOW() WHERE id=? AND user_id=?',
      [newValue, req.params.id, req.user.id]);

    res.json({ message: 'Favorite toggled', is_favorite: newValue === 1 });
  } catch (err) {
    console.error('PATCH /api/entries/:id/favorite error:', err);
    res.status(500).json({ error: 'Failed to toggle favorite' });
  }
});

// DELETE /api/entries/:id
router.delete('/:id', authenticateToken, async (req, res) => {
  try {
    const [result] = await pool.execute(
      'DELETE FROM journal_entries WHERE id = ? AND user_id = ?',
      [req.params.id, req.user.id]);
    if (result.affectedRows === 0) return res.status(404).json({ error: 'Entry not found' });
    res.json({ message: 'Entry deleted' });
  } catch (err) {
    console.error('DELETE /api/entries/:id error:', err);
    res.status(500).json({ error: 'Failed to delete entry' });
  }
});

module.exports = router;
