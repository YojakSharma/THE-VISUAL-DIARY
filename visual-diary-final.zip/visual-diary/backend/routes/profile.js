const express = require('express');
const router = express.Router();
const multer = require('multer');
const path = require('path');
const bcrypt = require('bcryptjs');
const { pool } = require('../config/db');
const { authenticateToken } = require('../middleware/auth');

// Multer config
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, path.join(__dirname, '../uploads'));
  },
  filename: (req, file, cb) => {
    const unique = Date.now() + '-' + Math.round(Math.random() * 1e9);
    cb(null, unique + path.extname(file.originalname));
  }
});

const upload = multer({
  storage,
  limits: { fileSize: 10 * 1024 * 1024 }, // 10MB
  fileFilter: (req, file, cb) => {
    const allowed = /jpeg|jpg|png|gif|webp/;
    const ext = allowed.test(path.extname(file.originalname).toLowerCase());
    const mime = allowed.test(file.mimetype);
    if (ext && mime) cb(null, true);
    else cb(new Error('Only image files allowed'));
  }
});

// GET /api/profile
router.get('/', authenticateToken, async (req, res) => {
  try {
    const [users] = await pool.execute(
      'SELECT id, username, email, display_name, bio, profile_image, theme, created_at FROM users WHERE id = ?',
      [req.user.id]
    );
    if (users.length === 0) return res.status(404).json({ error: 'User not found' });

    const [[stats]] = await pool.execute(
      'SELECT COUNT(*) as total_entries, COALESCE(SUM(word_count), 0) as total_words FROM journal_entries WHERE user_id = ?',
      [req.user.id]
    );

    res.json({ user: users[0], stats });
  } catch (err) {
    res.status(500).json({ error: 'Failed to fetch profile' });
  }
});

// PUT /api/profile
router.put('/', authenticateToken, async (req, res) => {
  const { display_name, bio, username } = req.body;
  try {
    if (username) {
      const [existing] = await pool.execute(
        'SELECT id FROM users WHERE username = ? AND id != ?', [username, req.user.id]
      );
      if (existing.length > 0) return res.status(409).json({ error: 'Username taken' });
    }

    await pool.execute(
      'UPDATE users SET display_name=?, bio=?, username=COALESCE(?,username) WHERE id=?',
      [display_name, bio, username || null, req.user.id]
    );
    res.json({ message: 'Profile updated' });
  } catch (err) {
    res.status(500).json({ error: 'Failed to update profile' });
  }
});

// PUT /api/profile/password
router.put('/password', authenticateToken, async (req, res) => {
  const { current_password, new_password } = req.body;
  if (!current_password || !new_password) return res.status(400).json({ error: 'Both passwords required' });
  if (new_password.length < 6) return res.status(400).json({ error: 'Password must be at least 6 characters' });

  try {
    const [users] = await pool.execute('SELECT password_hash FROM users WHERE id = ?', [req.user.id]);
    const isMatch = await bcrypt.compare(current_password, users[0].password_hash);
    if (!isMatch) return res.status(401).json({ error: 'Current password is incorrect' });

    const hash = await bcrypt.hash(new_password, 12);
    await pool.execute('UPDATE users SET password_hash=? WHERE id=?', [hash, req.user.id]);
    res.json({ message: 'Password updated' });
  } catch (err) {
    res.status(500).json({ error: 'Failed to update password' });
  }
});

// POST /api/profile/avatar - Upload profile image
router.post('/avatar', authenticateToken, upload.single('avatar'), async (req, res) => {
  if (!req.file) return res.status(400).json({ error: 'No image uploaded' });
  try {
    const imagePath = `/uploads/${req.file.filename}`;
    await pool.execute('UPDATE users SET profile_image=? WHERE id=?', [imagePath, req.user.id]);
    res.json({ message: 'Avatar updated', profile_image: imagePath });
  } catch (err) {
    res.status(500).json({ error: 'Failed to upload avatar' });
  }
});

// POST /api/profile/upload-image - Upload journal image
router.post('/upload-image', authenticateToken, upload.single('image'), async (req, res) => {
  if (!req.file) return res.status(400).json({ error: 'No image uploaded' });
  try {
    const { entry_id } = req.body;
    const imagePath = `/uploads/${req.file.filename}`;

    const [result] = await pool.execute(
      'INSERT INTO uploaded_images (user_id, entry_id, filename, original_name, file_path, file_size, mime_type) VALUES (?,?,?,?,?,?,?)',
      [req.user.id, entry_id || null, req.file.filename, req.file.originalname,
       imagePath, req.file.size, req.file.mimetype]
    );

    res.json({ message: 'Image uploaded', imageId: result.insertId, path: imagePath });
  } catch (err) {
    res.status(500).json({ error: 'Failed to upload image' });
  }
});

module.exports = router;
