const mysql = require('mysql2/promise');

// BUG-11 FIX: dateStrings:true → MySQL returns DATE columns as 'YYYY-MM-DD'
//   strings instead of JS Date objects, preventing UTC timezone off-by-one
//   issues that are common on Windows.
//
// Windows MySQL 8 note: if you see ER_NOT_SUPPORTED_AUTH_MODE, run this in
//   MySQL shell:  ALTER USER 'root'@'localhost' IDENTIFIED WITH
//                 mysql_native_password BY 'your_password'; FLUSH PRIVILEGES;

const pool = mysql.createPool({
  host:             process.env.DB_HOST     || 'localhost',
  user:             process.env.DB_USER     || 'root',
  password:         process.env.DB_PASSWORD || '',
  database:         process.env.DB_NAME     || 'visual_diary',
  waitForConnections: true,
  connectionLimit:  10,
  queueLimit:       0,
  dateStrings:      true,   // keeps dates as 'YYYY-MM-DD' strings — no UTC shift
  timezone:         'local', // use server local time, not forced UTC
});

const connectDB = async () => {
  try {
    const connection = await pool.getConnection();
    console.log('✅ MySQL connected successfully');
    connection.release();
  } catch (err) {
    console.error('❌ MySQL connection failed:', err.message);
    process.exit(1);
  }
};

module.exports = { pool, connectDB };
