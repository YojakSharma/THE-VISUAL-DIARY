-- ============================================================
-- THE VISUAL DIARY — MySQL Schema  (compatible with all MySQL 8.x)
-- Run once:  mysql -u root -p < schema.sql
-- ============================================================

CREATE DATABASE IF NOT EXISTS visual_diary
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE visual_diary;

-- USERS
CREATE TABLE IF NOT EXISTS users (
  id            INT AUTO_INCREMENT PRIMARY KEY,
  username      VARCHAR(50)  UNIQUE NOT NULL,
  email         VARCHAR(100) UNIQUE NOT NULL,
  password_hash VARCHAR(255) NOT NULL,
  display_name  VARCHAR(100),
  bio           TEXT,
  profile_image VARCHAR(255) DEFAULT NULL,
  theme         VARCHAR(50)  DEFAULT 'vintage-paper',
  created_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- JOURNAL ENTRIES
-- BUG-01 FIX: removed DEFAULT (CURRENT_DATE) — expression defaults
-- require MySQL 8.0.13+. App always provides entry_date on INSERT.
CREATE TABLE IF NOT EXISTS journal_entries (
  id          INT AUTO_INCREMENT PRIMARY KEY,
  user_id     INT          NOT NULL,
  title       VARCHAR(255) NOT NULL DEFAULT 'Untitled',
  content     LONGTEXT,
  mood        VARCHAR(50)  DEFAULT NULL,
  is_draft    TINYINT(1)   DEFAULT 0,
  is_favorite TINYINT(1)   DEFAULT 0,
  entry_date  DATE         DEFAULT NULL,
  word_count  INT          DEFAULT 0,
  created_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- MOODS
-- BUG-01 FIX: removed DEFAULT (CURRENT_DATE)
CREATE TABLE IF NOT EXISTS moods (
  id         INT AUTO_INCREMENT PRIMARY KEY,
  user_id    INT NOT NULL,
  entry_id   INT,
  mood_label VARCHAR(50) NOT NULL,
  mood_emoji VARCHAR(10),
  mood_date  DATE DEFAULT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id)  REFERENCES users(id)           ON DELETE CASCADE,
  FOREIGN KEY (entry_id) REFERENCES journal_entries(id) ON DELETE SET NULL
);

-- UPLOADED IMAGES
CREATE TABLE IF NOT EXISTS uploaded_images (
  id            INT AUTO_INCREMENT PRIMARY KEY,
  user_id       INT NOT NULL,
  entry_id      INT,
  filename      VARCHAR(255) NOT NULL,
  original_name VARCHAR(255),
  file_path     VARCHAR(500) NOT NULL,
  file_size     INT,
  mime_type     VARCHAR(100),
  created_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id)  REFERENCES users(id)           ON DELETE CASCADE,
  FOREIGN KEY (entry_id) REFERENCES journal_entries(id) ON DELETE SET NULL
);

-- THEMES
CREATE TABLE IF NOT EXISTS themes (
  id               INT AUTO_INCREMENT PRIMARY KEY,
  name             VARCHAR(50)  UNIQUE NOT NULL,
  display_name     VARCHAR(100) NOT NULL,
  background_color VARCHAR(20),
  text_color       VARCHAR(20),
  accent_color     VARCHAR(20),
  font_family      VARCHAR(100),
  description      TEXT,
  is_default       TINYINT(1) DEFAULT 0
);

-- USER SETTINGS
CREATE TABLE IF NOT EXISTS user_settings (
  id                    INT AUTO_INCREMENT PRIMARY KEY,
  user_id               INT        UNIQUE NOT NULL,
  theme                 VARCHAR(50) DEFAULT 'vintage-paper',
  font_size             VARCHAR(20) DEFAULT 'medium',
  notifications_enabled TINYINT(1)  DEFAULT 1,
  auto_save_interval    INT         DEFAULT 30,
  public_profile        TINYINT(1)  DEFAULT 0,
  daily_reminder_time   TIME        DEFAULT '20:00:00',
  created_at            TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at            TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- TAGS
CREATE TABLE IF NOT EXISTS tags (
  id         INT AUTO_INCREMENT PRIMARY KEY,
  user_id    INT         NOT NULL,
  entry_id   INT         NOT NULL,
  tag_name   VARCHAR(50) NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id)  REFERENCES users(id)           ON DELETE CASCADE,
  FOREIGN KEY (entry_id) REFERENCES journal_entries(id) ON DELETE CASCADE
);

-- SEED: default themes
INSERT IGNORE INTO themes
  (name, display_name, background_color, text_color, accent_color, font_family, description, is_default)
VALUES
  ('vintage-paper',   'Vintage Paper',   '#F5F0E8', '#2C2C2C', '#8B7355', 'Cormorant Garamond', 'Warm, aged paper aesthetic', 1),
  ('soft-beige',      'Soft Beige',      '#FAF6F0', '#3D3530', '#C4A882', 'Playfair Display',   'Gentle cream tones',         0),
  ('dotted-notebook', 'Dotted Notebook', '#FAFAFA',  '#2D2D2D', '#6B8F71', 'Caveat',             'Classic dotted journal',     0),
  ('minimal-white',   'Minimal White',   '#FFFFFF',  '#1A1A1A', '#B0927A', 'Inter',              'Clean, modern minimal',      0),
  ('dark-journal',    'Dark Journal',    '#1C1917',  '#F5F0E8', '#C4A882', 'Cormorant Garamond', 'Moody, night writing',       0);

-- INDEXES — BUG-10 FIX: IF NOT EXISTS prevents error on re-run
CREATE INDEX IF NOT EXISTS idx_entries_user_id ON journal_entries(user_id);
CREATE INDEX IF NOT EXISTS idx_entries_date    ON journal_entries(entry_date);
CREATE INDEX IF NOT EXISTS idx_moods_user_id   ON moods(user_id);
CREATE INDEX IF NOT EXISTS idx_images_entry_id ON uploaded_images(entry_id);
CREATE INDEX IF NOT EXISTS idx_tags_entry_id   ON tags(entry_id);
