/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ['./src/**/*.{js,jsx,ts,tsx}', './public/index.html'],
  theme: {
    extend: {
      colors: {
        cream:      '#F5F0E8',
        'cream-light': '#FAF7F2',
        'cream-dark':  '#EDE8DE',
        parchment:  '#E8E0D0',
        'parchment-dark': '#D4C9B8',
        bark:       '#8B7355',
        'bark-light': '#C4A882',
        'bark-dark':  '#6B5840',
        ink:        '#2C2420',
        'ink-light': '#5C4F44',
        'ink-muted': '#9A8B7E',
        blush:      '#E8D5C4',
        sage:       '#9CAF9C',
        dusty:      '#C4B8A8',
      },
      fontFamily: {
        serif:       ['"Cormorant Garamond"', 'Georgia', 'serif'],
        display:     ['"Playfair Display"', 'Georgia', 'serif'],
        handwritten: ['"Caveat"', 'cursive'],
        sans:        ['"DM Sans"', 'sans-serif'],
      },
      backgroundImage: {
        'paper-texture': "url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='300' height='300'%3E%3Cfilter id='noise'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.65' numOctaves='3' stitchTiles='stitch'/%3E%3CfeColorMatrix type='saturate' values='0'/%3E%3C/filter%3E%3Crect width='300' height='300' filter='url(%23noise)' opacity='0.04'/%3E%3C/svg%3E\")",
      },
      boxShadow: {
        'paper':    '0 2px 12px rgba(44,36,32,0.08), 0 1px 3px rgba(44,36,32,0.06)',
        'paper-md': '0 4px 20px rgba(44,36,32,0.10), 0 2px 6px rgba(44,36,32,0.06)',
        'paper-lg': '0 8px 32px rgba(44,36,32,0.12), 0 4px 12px rgba(44,36,32,0.08)',
        'polaroid': '4px 4px 14px rgba(44,36,32,0.18), 0 2px 4px rgba(44,36,32,0.10)',
        'tape':     '1px 1px 4px rgba(44,36,32,0.12)',
        'inset-soft': 'inset 0 1px 3px rgba(44,36,32,0.08)',
      },
      borderRadius: {
        'page': '12px',
        'card': '8px',
      },
      animation: {
        'float':      'float 6s ease-in-out infinite',
        'float-slow': 'float 9s ease-in-out infinite',
        'fade-up':    'fadeUp 0.6s ease forwards',
        'grain':      'grain 8s steps(10) infinite',
      },
      keyframes: {
        float: {
          '0%, 100%': { transform: 'translateY(0px)' },
          '50%':      { transform: 'translateY(-8px)' },
        },
        fadeUp: {
          from: { opacity: '0', transform: 'translateY(20px)' },
          to:   { opacity: '1', transform: 'translateY(0)' },
        },
        grain: {
          '0%, 100%': { backgroundPosition: '0 0' },
          '10%':      { backgroundPosition: '-5% -10%' },
          '20%':      { backgroundPosition: '-15% 5%' },
          '30%':      { backgroundPosition: '7% -25%' },
          '40%':      { backgroundPosition: '-5% 25%' },
          '50%':      { backgroundPosition: '-15% 10%' },
          '60%':      { backgroundPosition: '15% 0%' },
          '70%':      { backgroundPosition: '0% 15%' },
          '80%':      { backgroundPosition: '3% 35%' },
          '90%':      { backgroundPosition: '-10% 10%' },
        },
      },
    },
  },
  plugins: [],
};
