/**
 * theme.js — Central theme + font-size applicator
 *
 * HOW IT WORKS:
 * All CSS variables like --cream, --ink, --bark etc. are defined in
 * index.css under :root {}. JavaScript can OVERRIDE those variables
 * by calling document.documentElement.style.setProperty(name, value).
 * Inline styles on :root take priority over the stylesheet, so all
 * CSS rules that use var(--cream) etc. immediately reflect the new
 * colours — no React re-renders, no class toggling needed.
 *
 * Font size works the same way: setting document.documentElement.style
 * .fontSize changes the root font size, and all `rem` units in the
 * app scale proportionally.
 */

// ─── Theme → CSS variable values ─────────────────────────────
const THEME_VARS = {
  'vintage-paper': {
    '--cream':           '#F5F0E8',
    '--cream-light':     '#FAF7F2',
    '--cream-dark':      '#EDE8DE',
    '--parchment':       '#E8E0D0',
    '--parchment-dark':  '#D4C9B8',
    '--bark':            '#8B7355',
    '--bark-light':      '#C4A882',
    '--bark-dark':       '#6B5840',
    '--ink':             '#2C2420',
    '--ink-light':       '#5C4F44',
    '--ink-muted':       '#9A8B7E',
    '--blush':           '#E8D5C4',
    '--paper-shadow':    '0 2px 12px rgba(44,36,32,0.08), 0 1px 3px rgba(44,36,32,0.06)',
    '--paper-shadow-md': '0 4px 24px rgba(44,36,32,0.11), 0 2px 8px rgba(44,36,32,0.06)',
    '--paper-shadow-lg': '0 8px 40px rgba(44,36,32,0.13), 0 4px 14px rgba(44,36,32,0.08)',
  },
  'soft-beige': {
    '--cream':           '#FAF6F0',
    '--cream-light':     '#FDFAF6',
    '--cream-dark':      '#F0E8DC',
    '--parchment':       '#EAE0D2',
    '--parchment-dark':  '#D8CABB',
    '--bark':            '#8B7355',
    '--bark-light':      '#C4A882',
    '--bark-dark':       '#6B5840',
    '--ink':             '#3D3530',
    '--ink-light':       '#5C4F44',
    '--ink-muted':       '#9A8B7E',
    '--blush':           '#EAD8C8',
    '--paper-shadow':    '0 2px 12px rgba(44,36,32,0.07), 0 1px 3px rgba(44,36,32,0.05)',
    '--paper-shadow-md': '0 4px 24px rgba(44,36,32,0.10), 0 2px 8px rgba(44,36,32,0.05)',
    '--paper-shadow-lg': '0 8px 40px rgba(44,36,32,0.12), 0 4px 14px rgba(44,36,32,0.07)',
  },
  'dotted-notebook': {
    '--cream':           '#FAFAFA',
    '--cream-light':     '#FFFFFF',
    '--cream-dark':      '#F0F0F0',
    '--parchment':       '#E8E8E8',
    '--parchment-dark':  '#D8D8D8',
    '--bark':            '#6B8F71',
    '--bark-light':      '#8FAF95',
    '--bark-dark':       '#4A6B50',
    '--ink':             '#2D2D2D',
    '--ink-light':       '#4A4A4A',
    '--ink-muted':       '#888888',
    '--blush':           '#D4EAD6',
    '--paper-shadow':    '0 2px 12px rgba(0,0,0,0.06), 0 1px 3px rgba(0,0,0,0.04)',
    '--paper-shadow-md': '0 4px 24px rgba(0,0,0,0.09), 0 2px 8px rgba(0,0,0,0.04)',
    '--paper-shadow-lg': '0 8px 40px rgba(0,0,0,0.10), 0 4px 14px rgba(0,0,0,0.06)',
  },
  'minimal-white': {
    '--cream':           '#FFFFFF',
    '--cream-light':     '#FAFAFA',
    '--cream-dark':      '#F5F5F5',
    '--parchment':       '#EEEEEE',
    '--parchment-dark':  '#DEDEDE',
    '--bark':            '#B0927A',
    '--bark-light':      '#C8AA92',
    '--bark-dark':       '#8A7060',
    '--ink':             '#1A1A1A',
    '--ink-light':       '#444444',
    '--ink-muted':       '#888888',
    '--blush':           '#F0E8E0',
    '--paper-shadow':    '0 2px 12px rgba(0,0,0,0.06), 0 1px 3px rgba(0,0,0,0.04)',
    '--paper-shadow-md': '0 4px 24px rgba(0,0,0,0.08), 0 2px 8px rgba(0,0,0,0.04)',
    '--paper-shadow-lg': '0 8px 40px rgba(0,0,0,0.10), 0 4px 14px rgba(0,0,0,0.06)',
  },
  'dark-journal': {
    '--cream':           '#1C1917',
    '--cream-light':     '#231F1C',
    '--cream-dark':      '#161412',
    '--parchment':       '#2C2824',
    '--parchment-dark':  '#3A3430',
    '--bark':            '#C4A882',
    '--bark-light':      '#D4B892',
    '--bark-dark':       '#A08860',
    '--ink':             '#F5F0E8',
    '--ink-light':       '#D4C9B8',
    '--ink-muted':       '#8A7E72',
    '--blush':           '#3A2E28',
    '--paper-shadow':    '0 2px 12px rgba(0,0,0,0.30), 0 1px 3px rgba(0,0,0,0.20)',
    '--paper-shadow-md': '0 4px 24px rgba(0,0,0,0.35), 0 2px 8px rgba(0,0,0,0.20)',
    '--paper-shadow-lg': '0 8px 40px rgba(0,0,0,0.40), 0 4px 14px rgba(0,0,0,0.25)',
  },
};

// ─── Font size → root px value ────────────────────────────────
// Setting root font size scales ALL rem-based typography in the app.
const FONT_SIZE_MAP = {
  small:  '14px',   // 1rem = 14px  — compact writing
  medium: '16px',   // 1rem = 16px  — default browser size
  large:  '19px',   // 1rem = 19px  — comfortable reading
};

/**
 * applyTheme(theme, fontSize)
 *
 * Writes theme CSS variables directly to document.documentElement
 * (the <html> element). This overrides the :root stylesheet values
 * immediately, updating every var() reference in the app without
 * any component re-renders or class changes.
 *
 * @param {string} theme    — one of the THEME_VARS keys
 * @param {string} fontSize — 'small' | 'medium' | 'large'
 */
export function applyTheme(theme, fontSize) {
  const vars = THEME_VARS[theme] || THEME_VARS['vintage-paper'];
  const root = document.documentElement;

  // Apply each CSS variable
  Object.entries(vars).forEach(function(entry) {
    root.style.setProperty(entry[0], entry[1]);
  });

  // Apply root font size (scales all rem units in the app)
  var size = (fontSize && FONT_SIZE_MAP[fontSize]) ? FONT_SIZE_MAP[fontSize] : '16px';
  root.style.fontSize = size;
}

export { THEME_VARS, FONT_SIZE_MAP };
