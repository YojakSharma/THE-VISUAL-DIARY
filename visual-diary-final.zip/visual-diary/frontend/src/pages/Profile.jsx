import React, { useState, useEffect, useRef } from 'react';
import { motion } from 'framer-motion';
import { Camera, Edit3, Save, X, BookOpen, Zap, Heart, Award } from 'lucide-react';
import axios from 'axios';
import { format } from 'date-fns';
import AppLayout from '../components/AppLayout';
import { useAuth } from '../context/AuthContext';

const MOODS = {
  calm:       { emoji: '🌊', color: '#E8F0E8', text: '#4A6B4A' },
  happy:      { emoji: '☀️', color: '#F5EDD8', text: '#7A5C2A' },
  grateful:   { emoji: '🌸', color: '#F5E8F0', text: '#642A58' },
  peaceful:   { emoji: '🕊️', color: '#E8EFF0', text: '#2A5C64' },
  reflective: { emoji: '🌙', color: '#EEE8F5', text: '#4A2A6B' },
  anxious:    { emoji: '🌪️', color: '#F0E8E8', text: '#6B3535' },
  sad:        { emoji: '🌧️', color: '#E8ECF5', text: '#354466' },
  creative:   { emoji: '✨', color: '#F5EEE8', text: '#6B4A2A' },
};

const fadeUp = { hidden: { opacity: 0, y: 18 }, show: { opacity: 1, y: 0, transition: { duration: 0.5, ease: [0.22,1,0.36,1] } } };
const stagger = { show: { transition: { staggerChildren: 0.09 } } };

export default function Profile() {
  const { user, updateUser } = useAuth();
  const [profile, setProfile] = useState(null);
  const [stats, setStats]     = useState(null);
  const [entries, setEntries] = useState([]);
  const [editing, setEditing] = useState(false);
  const [form, setForm]       = useState({ display_name: '', bio: '', username: '' });
  const [saving, setSaving]   = useState(false);
  const [avatarLoading, setAvatarLoading] = useState(false);
  const [msg, setMsg]         = useState('');
  const fileRef = useRef(null);

  useEffect(() => {
    fetchProfile();
    axios.get('/api/entries?limit=9').then(r => setEntries(r.data.entries || [])).catch(() => {});
  }, []);

  const fetchProfile = async () => {
    try {
      const { data } = await axios.get('/api/profile');
      setProfile(data.user);
      setStats(data.stats);
      setForm({ display_name: data.user.display_name || '', bio: data.user.bio || '', username: data.user.username || '' });
    } catch {}
  };

  const handleSave = async () => {
    setSaving(true);
    try {
      await axios.put('/api/profile', form);
      updateUser({ display_name: form.display_name, username: form.username });
      await fetchProfile();
      setEditing(false);
      setMsg('Profile updated!');
      setTimeout(() => setMsg(''), 2500);
    } catch (err) {
      setMsg(err.response?.data?.error || 'Failed to update');
    }
    setSaving(false);
  };

  const handleAvatar = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setAvatarLoading(true);
    const fd = new FormData();
    fd.append('avatar', file);
    try {
      const { data } = await axios.post('/api/profile/avatar', fd, { headers: { 'Content-Type': 'multipart/form-data' } });
      updateUser({ profile_image: data.profile_image });
      await fetchProfile();
      setMsg('Avatar updated!');
      setTimeout(() => setMsg(''), 2500);
    } catch { setMsg('Upload failed'); }
    setAvatarLoading(false);
    e.target.value = '';
  };

  if (!profile) return (
    <AppLayout>
      <div style={{ display: 'flex', justifyContent: 'center', padding: '80px 0' }}>
        <div style={{ fontFamily: "'Cormorant Garamond', serif", fontStyle: 'italic', color: '#9A8B7E', fontSize: '1.1rem' }}>
          Loading your profile...
        </div>
      </div>
    </AppLayout>
  );

  return (
    <AppLayout>
      <motion.div variants={stagger} initial="hidden" animate="show">

        {/* ── Hero banner ─────────────────────────────── */}
        <motion.div variants={fadeUp}
          style={{
            borderRadius: 16, overflow: 'hidden', marginBottom: 24, position: 'relative',
            height: 180,
            background: 'linear-gradient(135deg, #E8E0D0 0%, #D4C9B8 40%, #C4B4A4 100%)',
          }}>
          {/* Decorative texture */}
          <div style={{ position: 'absolute', inset: 0, backgroundImage: `url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='200' height='200'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.65' numOctaves='3' stitchTiles='stitch'/%3E%3CfeColorMatrix type='saturate' values='0'/%3E%3C/filter%3E%3Crect width='200' height='200' filter='url(%23n)' opacity='0.06'/%3E%3C/svg%3E")`, backgroundSize: '180px 180px' }} />
          {/* Botanical */}
          <div style={{ position: 'absolute', right: 40, bottom: -10, fontSize: 120, opacity: 0.1, transform: 'rotate(15deg)' }}>🌿</div>
          <div style={{ position: 'absolute', left: 60, top: 20, fontSize: 60, opacity: 0.08 }}>🌸</div>
          {/* Quote on banner */}
          <div style={{ position: 'absolute', bottom: 20, left: 200, fontFamily: "'Caveat', cursive", fontSize: 20, color: 'rgba(44,36,32,0.5)', fontStyle: 'italic' }}>
            writing one page at a time...
          </div>
        </motion.div>

        {/* ── Profile card ────────────────────────────── */}
        <motion.div variants={fadeUp}
          style={{ background: '#FAF7F2', borderRadius: 14, padding: '24px 28px', border: '1px solid rgba(212,201,184,0.45)', marginBottom: 24, marginTop: -60, position: 'relative', zIndex: 5 }}>
          <div style={{ display: 'flex', alignItems: 'flex-start', gap: 24 }}>

            {/* Avatar */}
            <div style={{ position: 'relative', flexShrink: 0 }}>
              <div style={{
                width: 88, height: 88, borderRadius: '50%', overflow: 'hidden',
                border: '4px solid #FAF7F2', boxShadow: '0 0 0 2px #C4A882, 0 4px 16px rgba(44,36,32,0.15)',
                background: 'linear-gradient(135deg,#C4A882,#8B7355)',
                display: 'flex', alignItems: 'center', justifyContent: 'center',
              }}>
                {profile.profile_image
                  ? <img src={`http://localhost:5000${profile.profile_image}`} alt="" style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
                  : <span style={{ fontFamily: "'Playfair Display', serif", fontWeight: 800, fontSize: 32, color: 'white' }}>
                      {(profile.display_name || profile.username || 'U')[0].toUpperCase()}
                    </span>
                }
              </div>
              <button onClick={() => fileRef.current?.click()} disabled={avatarLoading}
                style={{
                  position: 'absolute', bottom: 0, right: 0,
                  width: 28, height: 28, borderRadius: '50%',
                  background: '#2C2420', border: '2px solid #FAF7F2',
                  cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#FAF7F2',
                }}>
                <Camera size={13} />
              </button>
              <input ref={fileRef} type="file" accept="image/*" onChange={handleAvatar} style={{ display: 'none' }} />
            </div>

            {/* Info */}
            <div style={{ flex: 1 }}>
              {editing ? (
                <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
                  <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10 }}>
                    <div>
                      <label style={{ fontFamily: "'DM Sans', sans-serif", fontSize: 11, fontWeight: 500, color: '#5C4F44', textTransform: 'uppercase', letterSpacing: '0.07em', display: 'block', marginBottom: 4 }}>Display Name</label>
                      <input value={form.display_name} onChange={e => setForm(f => ({...f, display_name: e.target.value}))}
                        className="paper-input" style={{ fontSize: 13 }} />
                    </div>
                    <div>
                      <label style={{ fontFamily: "'DM Sans', sans-serif", fontSize: 11, fontWeight: 500, color: '#5C4F44', textTransform: 'uppercase', letterSpacing: '0.07em', display: 'block', marginBottom: 4 }}>Username</label>
                      <input value={form.username} onChange={e => setForm(f => ({...f, username: e.target.value}))}
                        className="paper-input" style={{ fontSize: 13 }} />
                    </div>
                  </div>
                  <div>
                    <label style={{ fontFamily: "'DM Sans', sans-serif", fontSize: 11, fontWeight: 500, color: '#5C4F44', textTransform: 'uppercase', letterSpacing: '0.07em', display: 'block', marginBottom: 4 }}>Bio</label>
                    <textarea value={form.bio} onChange={e => setForm(f => ({...f, bio: e.target.value}))}
                      placeholder="A few words about yourself..."
                      rows={2}
                      style={{ width: '100%', padding: '10px 12px', background: '#F5F0E8', border: '1.5px solid rgba(212,201,184,0.6)', borderRadius: 8, fontFamily: "'DM Sans', sans-serif", fontSize: 13, color: '#2C2420', outline: 'none', resize: 'none' }} />
                  </div>
                  <div style={{ display: 'flex', gap: 8 }}>
                    <button onClick={handleSave} disabled={saving} className="btn-primary" style={{ fontSize: 13, padding: '8px 20px' }}>
                      <Save size={13} /> {saving ? 'Saving...' : 'Save Changes'}
                    </button>
                    <button onClick={() => setEditing(false)} className="btn-ghost" style={{ fontSize: 13, padding: '8px 16px' }}>
                      <X size={13} /> Cancel
                    </button>
                  </div>
                </div>
              ) : (
                <>
                  <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between' }}>
                    <div>
                      <div style={{ fontFamily: "'Playfair Display', serif", fontWeight: 700, fontSize: '1.5rem', color: '#2C2420', marginBottom: 2 }}>
                        {profile.display_name || profile.username}
                      </div>
                      <div style={{ fontFamily: "'DM Sans', sans-serif", fontSize: 13, color: '#9A8B7E', marginBottom: 8 }}>
                        @{profile.username}
                      </div>
                      {profile.bio && (
                        <div style={{ fontFamily: "'Cormorant Garamond', serif", fontStyle: 'italic', fontSize: '1rem', color: '#5C4F44', lineHeight: 1.6, maxWidth: 400 }}>
                          {profile.bio}
                        </div>
                      )}
                      <div style={{ fontFamily: "'DM Sans', sans-serif", fontSize: 11, color: '#B8A99A', marginTop: 8 }}>
                        Member since {profile.created_at ? format(new Date(profile.created_at), 'MMMM yyyy') : ''}
                      </div>
                    </div>
                    <button onClick={() => setEditing(true)}
                      style={{ display: 'flex', alignItems: 'center', gap: 6, padding: '7px 14px', background: 'none', border: '1px solid rgba(212,201,184,0.7)', borderRadius: 8, cursor: 'pointer', fontFamily: "'DM Sans', sans-serif", fontSize: 12, color: '#5C4F44', transition: 'all 0.2s' }}
                      onMouseEnter={e => e.currentTarget.style.background = '#E8E0D0'}
                      onMouseLeave={e => e.currentTarget.style.background = 'none'}>
                      <Edit3 size={12} /> Edit
                    </button>
                  </div>
                </>
              )}
              {msg && (
                <motion.div initial={{ opacity: 0, y: -6 }} animate={{ opacity: 1, y: 0 }}
                  style={{ marginTop: 10, fontFamily: "'DM Sans', sans-serif", fontSize: 12, color: '#4A6B4A', padding: '6px 12px', background: '#E8F0E8', borderRadius: 6, display: 'inline-block' }}>
                  {msg}
                </motion.div>
              )}
            </div>
          </div>
        </motion.div>

        {/* ── Stats row ───────────────────────────────── */}
        <motion.div variants={fadeUp}
          style={{ display: 'grid', gridTemplateColumns: 'repeat(4,1fr)', gap: 14, marginBottom: 24 }}>
          {[
            { icon: BookOpen, value: stats?.total_entries ?? '–', label: 'Total Entries',  color: '#E8F0E8', iconColor: '#4A6B4A' },
            { icon: Zap,      value: '–',                          label: 'Day Streak',    color: '#F5EDD8', iconColor: '#7A5C2A' },
            { icon: Heart,    value: '–',                          label: 'Favorites',     color: '#F5E8F0', iconColor: '#642A58' },
            { icon: Award,    value: stats?.total_words >= 1000 ? (stats.total_words/1000).toFixed(1)+'k' : (stats?.total_words ?? '–'), label: 'Words Written', color: '#EEE8F5', iconColor: '#4A2A6B' },
          ].map(({ icon: Icon, value, label, color, iconColor }) => (
            <motion.div key={label} whileHover={{ y: -3 }} transition={{ duration: 0.2 }}
              style={{ background: '#FAF7F2', border: '1px solid rgba(212,201,184,0.45)', borderRadius: 12, padding: '18px 16px' }}>
              <div style={{ width: 36, height: 36, borderRadius: 10, background: color, display: 'flex', alignItems: 'center', justifyContent: 'center', marginBottom: 10, color: iconColor }}>
                <Icon size={17} />
              </div>
              <div style={{ fontFamily: "'Playfair Display', serif", fontWeight: 700, fontSize: '1.6rem', color: '#2C2420', lineHeight: 1 }}>{value}</div>
              <div style={{ fontFamily: "'DM Sans', sans-serif", fontSize: 11, color: '#9A8B7E', marginTop: 4 }}>{label}</div>
            </motion.div>
          ))}
        </motion.div>

        {/* ── Two column ──────────────────────────────── */}
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 280px', gap: 20 }}>

          {/* Memory gallery */}
          <motion.div variants={fadeUp}
            style={{ background: '#FAF7F2', borderRadius: 14, padding: '22px 22px', border: '1px solid rgba(212,201,184,0.45)' }}>
            <div style={{ fontFamily: "'Playfair Display', serif", fontWeight: 600, fontSize: '1.1rem', color: '#2C2420', marginBottom: 16 }}>
              Memory Gallery
            </div>
            {entries.length === 0 ? (
              <div style={{ textAlign: 'center', padding: '32px 0', fontFamily: "'Cormorant Garamond', serif", fontStyle: 'italic', color: '#9A8B7E' }}>
                Your gallery is empty — start writing to fill it.
              </div>
            ) : (
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3,1fr)', gap: 10 }}>
                {entries.map((entry, i) => {
                  const mood = MOODS[entry.mood];
                  return (
                    <motion.div key={entry.id}
                      initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }}
                      transition={{ delay: i * 0.05 }}
                      whileHover={{ scale: 1.04, zIndex: 10 }}
                      style={{
                        borderRadius: 10, overflow: 'hidden', cursor: 'pointer',
                        background: mood ? mood.color : '#EDE8DE',
                        aspectRatio: '1', position: 'relative',
                        boxShadow: '0 2px 8px rgba(44,36,32,0.08)',
                      }}>
                      {entry.cover_image ? (
                        <img src={`http://localhost:5000/uploads/${entry.cover_image}`} alt=""
                          style={{ width: '100%', height: '100%', objectFit: 'cover', filter: 'saturate(0.82)' }} />
                      ) : (
                        <div style={{ width: '100%', height: '100%', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 4 }}>
                          {mood && <span style={{ fontSize: 20 }}>{mood.emoji}</span>}
                          <div style={{ fontFamily: "'Caveat', cursive", fontSize: 11, color: mood?.text || '#5C4F44', textAlign: 'center', padding: '0 6px', lineHeight: 1.3 }}>
                            {entry.title?.slice(0, 24)}
                          </div>
                        </div>
                      )}
                      <div style={{ position: 'absolute', inset: 0, background: 'linear-gradient(to top, rgba(44,36,32,0.35) 0%, transparent 60%)', opacity: 0, transition: 'opacity 0.2s' }}
                        onMouseEnter={e => e.currentTarget.style.opacity = 1}
                        onMouseLeave={e => e.currentTarget.style.opacity = 0} />
                    </motion.div>
                  );
                })}
              </div>
            )}
          </motion.div>

          {/* Mood story panel */}
          <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
            <motion.div variants={fadeUp}
              style={{ background: '#FAF7F2', borderRadius: 14, padding: '20px 18px', border: '1px solid rgba(212,201,184,0.45)' }}>
              <div style={{ fontFamily: "'Playfair Display', serif", fontWeight: 600, fontSize: '1rem', color: '#2C2420', marginBottom: 14 }}>
                Emotional Palette
              </div>
              <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
                {Object.entries(MOODS).map(([id, m]) => (
                  <div key={id} style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                    <span style={{ fontSize: 16 }}>{m.emoji}</span>
                    <div style={{ flex: 1, height: 6, borderRadius: 3, background: '#E8E0D0', overflow: 'hidden' }}>
                      <div style={{ height: '100%', width: `${Math.random() * 70 + 5}%`, background: m.color, borderRadius: 3, border: `1px solid ${m.text}30` }} />
                    </div>
                    <span style={{ fontFamily: "'DM Sans', sans-serif", fontSize: 10, color: '#9A8B7E', width: 60 }}>{id}</span>
                  </div>
                ))}
              </div>
            </motion.div>

            {/* Botanical decorative card */}
            <motion.div variants={fadeUp}
              style={{ background: '#EDE8DE', borderRadius: 14, padding: '20px 18px', position: 'relative', overflow: 'hidden' }}>
              <div style={{ position: 'absolute', bottom: -8, right: -4, fontSize: 72, opacity: 0.18 }}>🌿</div>
              <div style={{ fontFamily: "'Caveat', cursive", fontSize: 17, color: '#3D3025', lineHeight: 1.55, position: 'relative', zIndex: 1 }}>
                "Every journal entry is a small act of self-love."
              </div>
            </motion.div>
          </div>
        </div>
      </motion.div>
    </AppLayout>
  );
}
