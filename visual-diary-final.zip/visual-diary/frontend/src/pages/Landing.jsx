import React, { useEffect, useRef } from 'react';
import { Link } from 'react-router-dom';
import { motion, useInView } from 'framer-motion';
import {
  BookOpen, Heart, Calendar, TrendingUp, Tag, Lock,
  Palette, Download, Search, Moon, Archive, Smartphone,
  Twitter, Instagram
} from 'lucide-react';

/* ── Helpers ───────────────────────────────────────────── */
const fadeUp = { hidden: { opacity: 0, y: 28 }, show: { opacity: 1, y: 0 } };
const stagger = { show: { transition: { staggerChildren: 0.12 } } };

function Section({ children, className = '' }) {
  const ref = useRef(null);
  const inView = useInView(ref, { once: true, margin: '-60px' });
  return (
    <motion.div ref={ref} variants={stagger} initial="hidden" animate={inView ? 'show' : 'hidden'}
      className={className}>
      {children}
    </motion.div>
  );
}

/* ── Tape decoration ──────────────────────────────────── */
const Tape = ({ className = '', rotate = '-2deg', width = 60 }) => (
  <div className={`absolute z-10 ${className}`}
    style={{
      width, height: 22, transform: `rotate(${rotate})`,
      background: 'rgba(220,198,155,0.55)',
      borderRadius: 3,
      boxShadow: '1px 1px 4px rgba(44,36,32,0.10)',
    }}>
    <div style={{
      position: 'absolute', inset: 0, borderRadius: 3,
      background: 'repeating-linear-gradient(45deg,transparent,transparent 3px,rgba(255,255,255,0.18) 3px,rgba(255,255,255,0.18) 6px)'
    }} />
  </div>
);

/* ── Polaroid ─────────────────────────────────────────── */
const Polaroid = ({ src, caption, rotate = 0, className = '', delay = 0 }) => (
  <motion.div
    className={`absolute ${className}`}
    style={{ transform: `rotate(${rotate}deg)`, transformOrigin: 'center center' }}
    initial={{ opacity: 0, y: 30, rotate: rotate - 5 }}
    animate={{ opacity: 1, y: 0, rotate }}
    transition={{ duration: 0.8, delay, ease: [0.22, 1, 0.36, 1] }}
    whileHover={{ scale: 1.04, zIndex: 20, boxShadow: '8px 10px 28px rgba(44,36,32,0.22)' }}
  >
    <div style={{
      background: '#FFFDF8', padding: '9px 9px 36px 9px',
      boxShadow: '5px 7px 20px rgba(44,36,32,0.18), 0 2px 5px rgba(44,36,32,0.10)',
    }}>
      <div style={{ width: 180, height: 215, overflow: 'hidden', background: '#E8E0D0' }}>
        {src
          ? <img src={src} alt={caption} style={{ width: '100%', height: '100%', objectFit: 'cover', filter: 'saturate(0.85)' }} />
          : <div style={{ width: '100%', height: '100%', background: 'linear-gradient(135deg,#D4C9B8 0%,#B8A99A 100%)' }} />
        }
      </div>
      {caption && (
        <div style={{ fontFamily: "'Caveat', cursive", fontSize: 14, color: '#5C4F44',
          textAlign: 'center', marginTop: 6, paddingInline: 4 }}>{caption}</div>
      )}
    </div>
  </motion.div>
);

/* ── Sticky Note ─────────────────────────────────────── */
const StickyNote = ({ children, rotate = 0, className = '', delay = 0 }) => (
  <motion.div
    className={`absolute ${className}`}
    style={{ transform: `rotate(${rotate}deg)` }}
    initial={{ opacity: 0, scale: 0.9 }}
    animate={{ opacity: 1, scale: 1 }}
    transition={{ duration: 0.6, delay }}
  >
    <Tape style={{ top: -11, left: '50%', transform: 'translateX(-50%)' }} />
    <div style={{
      background: '#F5EDD6', padding: '16px 20px', minWidth: 180, maxWidth: 220,
      boxShadow: '2px 4px 14px rgba(44,36,32,0.12)',
      fontFamily: "'Caveat', cursive", fontSize: 18, lineHeight: 1.5, color: '#3D3025',
    }}>
      {children}
    </div>
  </motion.div>
);

/* ── Feature Item ────────────────────────────────────── */
const FeatureItem = ({ icon: Icon, title, desc }) => (
  <motion.div variants={fadeUp} className="flex flex-col items-center text-center gap-2" style={{ maxWidth: 130 }}>
    <div style={{
      width: 44, height: 44, borderRadius: 12,
      border: '1.5px solid #D4C9B8', background: '#FAF7F2',
      display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#8B7355',
    }}>
      <Icon size={20} />
    </div>
    <div style={{ fontFamily: "'DM Sans', sans-serif", fontWeight: 600, fontSize: 13, color: '#2C2420' }}>{title}</div>
    <div style={{ fontFamily: "'DM Sans', sans-serif", fontSize: 12, color: '#9A8B7E', lineHeight: 1.5 }}>{desc}</div>
  </motion.div>
);

/* ── MAIN COMPONENT ────────────────────────────────────── */
export default function Landing() {
  return (
    <div style={{ background: '#F5F0E8', minHeight: '100vh', overflowX: 'hidden' }}>

      {/* ─── NAVBAR ─────────────────────────────────────── */}
      <motion.nav
        initial={{ opacity: 0, y: -16 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        style={{
          position: 'sticky', top: 0, zIndex: 100,
          background: 'rgba(245,240,232,0.88)',
          backdropFilter: 'blur(16px)',
          borderBottom: '1px solid rgba(212,201,184,0.4)',
          padding: '0 5vw',
          display: 'flex', alignItems: 'center', justifyContent: 'space-between',
          height: 60,
        }}
      >
        <div style={{ fontFamily: "'Playfair Display', serif", fontWeight: 700, fontSize: 16, letterSpacing: '0.03em', color: '#2C2420', lineHeight: 1.1 }}>
          THE<br />VISUAL<br />DIARY
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 32 }}>
          {['Home', 'Features', 'Journal', 'About'].map(l => (
            <a key={l} href={`#${l.toLowerCase()}`} style={{
              fontFamily: "'DM Sans', sans-serif", fontSize: 14, color: '#5C4F44',
              textDecoration: 'none', transition: 'color 0.2s',
            }}
              onMouseEnter={e => e.target.style.color = '#2C2420'}
              onMouseLeave={e => e.target.style.color = '#5C4F44'}
            >{l}</a>
          ))}
        </div>
        <Link to="/signup" style={{
          display: 'inline-flex', alignItems: 'center', padding: '9px 22px',
          background: '#2C2420', color: '#F5F0E8', borderRadius: 8,
          fontFamily: "'DM Sans', sans-serif", fontSize: 13, fontWeight: 500,
          textDecoration: 'none', transition: 'all 0.2s',
        }}
          onMouseEnter={e => e.currentTarget.style.background = '#6B5840'}
          onMouseLeave={e => e.currentTarget.style.background = '#2C2420'}
        >
          Get Started
        </Link>
      </motion.nav>

      {/* ─── HERO ───────────────────────────────────────── */}
      <section id="home" style={{ minHeight: 'calc(100vh - 60px)', display: 'flex', alignItems: 'center', padding: '60px 5vw 80px', position: 'relative', overflow: 'hidden' }}>

        {/* Paper texture overlay */}
        <div style={{
          position: 'absolute', inset: 0, pointerEvents: 'none', opacity: 0.4,
          backgroundImage: `url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='300' height='300'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.75' numOctaves='4' stitchTiles='stitch'/%3E%3CfeColorMatrix type='saturate' values='0'/%3E%3C/filter%3E%3Crect width='300' height='300' filter='url(%23n)' opacity='0.06'/%3E%3C/svg%3E")`,
          backgroundSize: '200px 200px',
        }} />

        {/* LEFT — Typography */}
        <div style={{ flex: '0 0 auto', maxWidth: 520, zIndex: 5 }}>
          <motion.div
            initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ duration: 0.5 }}
            style={{ fontFamily: "'Cormorant Garamond', serif", fontStyle: 'italic', fontWeight: 400,
              fontSize: 'clamp(1rem, 2vw, 1.4rem)', letterSpacing: '0.3em', color: '#9A8B7E',
              textTransform: 'uppercase', marginBottom: 8 }}>
            The
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: -40 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.9, delay: 0.15, ease: [0.22, 1, 0.36, 1] }}
            style={{
              fontFamily: "'Playfair Display', serif", fontWeight: 900,
              fontSize: 'clamp(5.5rem, 12vw, 11rem)',
              lineHeight: 0.85, letterSpacing: '-0.03em', color: '#2C2420',
            }}>
            VISUAL
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: -40 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.9, delay: 0.28, ease: [0.22, 1, 0.36, 1] }}
            style={{
              fontFamily: "'Playfair Display', serif", fontWeight: 900,
              fontSize: 'clamp(5.5rem, 12vw, 11rem)',
              lineHeight: 0.85, letterSpacing: '-0.03em', color: '#2C2420',
              marginBottom: 28,
            }}>
            DIARY
          </motion.div>

          <motion.p
            initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.7, delay: 0.5 }}
            style={{ fontFamily: "'Cormorant Garamond', serif", fontSize: '1.25rem', fontStyle: 'italic',
              color: '#5C4F44', lineHeight: 1.7, marginBottom: 36, maxWidth: 340 }}>
            A quiet space to think, write<br />and reflect everyday.
          </motion.p>

          <motion.div
            initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6, delay: 0.65 }}
            style={{ display: 'flex', gap: 12 }}>
            <Link to="/signup" className="btn-primary" style={{ fontSize: 15, padding: '12px 28px' }}>
              Start Writing
            </Link>
            <Link to="/login" className="btn-ghost" style={{ fontSize: 15, padding: '12px 28px' }}>
              View Your Journal
            </Link>
          </motion.div>
        </div>

        {/* RIGHT — Scrapbook collage */}
        <div style={{ flex: 1, position: 'relative', minHeight: 520, marginLeft: '5vw', zIndex: 5 }}>

          {/* Main polaroid */}
          <Polaroid rotate={-3} caption="quiet moments" delay={0.4}
            style={{ top: '5%', left: '15%', zIndex: 8 }} />

          {/* Sticky note */}
          <StickyNote rotate={1.5} delay={0.6}
            className="" style={{ top: '2%', right: '12%', zIndex: 9 }}>
            Take a deep breath.
          </StickyNote>

          {/* Larger note */}
          <motion.div
            initial={{ opacity: 0, x: 30 }} animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.7, delay: 0.75 }}
            style={{
              position: 'absolute', top: '25%', right: '5%', zIndex: 7,
              background: '#FAF7F2', padding: '24px 28px', maxWidth: 240,
              borderRadius: 4, transform: 'rotate(0.5deg)',
              boxShadow: '3px 5px 18px rgba(44,36,32,0.12)',
              fontFamily: "'Cormorant Garamond', serif", fontSize: '1.5rem',
              fontStyle: 'italic', color: '#2C2420', lineHeight: 1.4,
            }}>
            <Tape style={{ top: -11, left: '50%', transform: 'translateX(-50%)' }} />
            Every page holds a moment you'll want to remember.
          </motion.div>

          {/* Stamp */}
          <motion.div
            initial={{ opacity: 0, scale: 0.5, rotate: -10 }}
            animate={{ opacity: 1, scale: 1, rotate: -8 }}
            transition={{ duration: 0.5, delay: 1.0 }}
            style={{
              position: 'absolute', bottom: '15%', right: '30%', zIndex: 10,
              width: 80, height: 80, borderRadius: '50%',
              border: '2px solid #2C2420', display: 'flex', alignItems: 'center',
              justifyContent: 'center', flexDirection: 'column',
            }}>
            <div style={{ position: 'absolute', inset: 5, borderRadius: '50%', border: '1px dashed #2C2420' }} />
            <div style={{ fontFamily: "'DM Sans', sans-serif", fontSize: 8, fontWeight: 700,
              letterSpacing: '0.15em', color: '#2C2420', textAlign: 'center', lineHeight: 1.6,
              textTransform: 'uppercase' }}>
              WRITE.<br />REFLECT.<br />GROW.
            </div>
          </motion.div>

          {/* Floating dried flower / botanical squiggle */}
          <motion.div
            animate={{ rotate: [0, 3, 0, -3, 0] }}
            transition={{ duration: 8, repeat: Infinity }}
            style={{ position: 'absolute', bottom: '5%', left: '25%', fontSize: 52, zIndex: 6, opacity: 0.5 }}>
            🌿
          </motion.div>
          <motion.div
            animate={{ rotate: [0, -4, 0, 4, 0] }}
            transition={{ duration: 11, repeat: Infinity, delay: 2 }}
            style={{ position: 'absolute', top: '8%', left: '5%', fontSize: 36, zIndex: 6, opacity: 0.35 }}>
            🌸
          </motion.div>

          {/* Second polaroid, partially hidden */}
          <motion.div
            initial={{ opacity: 0, rotate: -15, scale: 0.8 }}
            animate={{ opacity: 1, rotate: 4, scale: 1 }}
            transition={{ duration: 0.8, delay: 0.9 }}
            style={{
              position: 'absolute', bottom: '0%', left: '0%', zIndex: 6,
              background: '#FFFDF8', padding: '8px 8px 32px 8px',
              boxShadow: '4px 6px 16px rgba(44,36,32,0.16)',
              width: 140,
            }}>
            <div style={{ width: '100%', height: 120, background: 'linear-gradient(135deg, #C4B4A2 0%, #A89888 100%)' }} />
            <div style={{ fontFamily: "'Caveat', cursive", fontSize: 13, color: '#5C4F44',
              textAlign: 'center', marginTop: 6 }}>sunday mood</div>
          </motion.div>

        </div>
      </section>

      {/* ─── FEATURES ───────────────────────────────────── */}
      <section id="features" style={{ background: '#FAF7F2', padding: '80px 5vw', borderTop: '1px solid rgba(212,201,184,0.5)' }}>
        <Section>
          <motion.div variants={fadeUp} style={{ marginBottom: 56 }}>
            <div style={{ fontFamily: "'Cormorant Garamond', serif", fontStyle: 'italic', color: '#9A8B7E', fontSize: '1rem', letterSpacing: '0.2em', textTransform: 'uppercase', marginBottom: 8 }}>What's inside</div>
            <div style={{ fontFamily: "'Playfair Display', serif", fontSize: 'clamp(2rem, 5vw, 3.2rem)', fontWeight: 700, color: '#2C2420', lineHeight: 1.1 }}>Features</div>
          </motion.div>

          <div style={{ display: 'flex', flexWrap: 'wrap', gap: 40 }}>
            {[
              { icon: BookOpen, title: 'Daily Journaling', desc: 'Write your thoughts and feelings everyday.' },
              { icon: Heart, title: 'Mood Tracking', desc: 'Track your mood and see your emotional journey.' },
              { icon: Calendar, title: 'Calendar View', desc: 'Look back at your memories anytime you want.' },
              { icon: TrendingUp, title: 'Streaks', desc: 'Build a writing habit and keep your streak alive.' },
              { icon: Tag, title: 'Categories', desc: 'Organize your entries with custom tags.' },
              { icon: Lock, title: 'Secure & Private', desc: 'Your thoughts are safe and only yours.' },
            ].map((f, i) => (
              <FeatureItem key={i} {...f} />
            ))}
          </div>

          <div style={{ marginTop: 56, paddingTop: 40, borderTop: '1px solid rgba(212,201,184,0.5)' }}>
            <motion.div variants={fadeUp} style={{ fontFamily: "'Playfair Display', serif", fontSize: 'clamp(1.4rem, 3vw, 2rem)', fontWeight: 600, color: '#2C2420', marginBottom: 32 }}>
              Extras You'll Love
            </motion.div>
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: 36 }}>
              {[
                { icon: Palette, title: 'Themes', desc: 'Choose themes that match your vibe.' },
                { icon: Download, title: 'Export', desc: 'Export your entries as PDF or TXT.' },
                { icon: Search, title: 'Search', desc: 'Find any memory in seconds.' },
                { icon: Moon, title: 'Dark Mode', desc: 'Easy on the eyes, day and night.' },
                { icon: Archive, title: 'Backup', desc: 'Never lose your memories.' },
                { icon: Smartphone, title: 'Responsive', desc: 'Works perfectly on all devices.' },
              ].map((f, i) => (
                <FeatureItem key={i} {...f} />
              ))}
            </div>
          </div>
        </Section>
      </section>

      {/* ─── DASHBOARD PREVIEW ──────────────────────────── */}
      <section id="journal" style={{ padding: '80px 5vw', position: 'relative', overflow: 'hidden' }}>
        <Section>
          <motion.div variants={fadeUp} style={{ marginBottom: 48, textAlign: 'center' }}>
            <div style={{ fontFamily: "'Cormorant Garamond', serif", fontStyle: 'italic', color: '#9A8B7E', fontSize: '1rem', letterSpacing: '0.2em', textTransform: 'uppercase', marginBottom: 8 }}>Your space</div>
            <div style={{ fontFamily: "'Playfair Display', serif", fontSize: 'clamp(2rem, 4vw, 2.8rem)', fontWeight: 700, color: '#2C2420', lineHeight: 1.1 }}>A place that feels like home</div>
          </motion.div>

          {/* Mock dashboard preview */}
          <motion.div variants={fadeUp}>
            <div style={{
              background: '#FAF7F2', borderRadius: 16, padding: '32px',
              boxShadow: '0 8px 40px rgba(44,36,32,0.10), 0 2px 8px rgba(44,36,32,0.06)',
              border: '1px solid rgba(212,201,184,0.4)',
              display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 24,
            }}>
              {/* Left panel */}
              <div>
                <div style={{ fontFamily: "'Playfair Display', serif", fontWeight: 600, fontSize: '1.4rem', color: '#2C2420', marginBottom: 6 }}>Dashboard</div>
                <div style={{ fontFamily: "'DM Sans', sans-serif", fontSize: 13, color: '#9A8B7E', marginBottom: 24 }}>Keep going, you're doing great.</div>
                <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4,1fr)', gap: 12, marginBottom: 24 }}>
                  {[['32','Entries'],['12','Days Streak'],['8','Categories'],['4.2k','Words Written']].map(([v,l]) => (
                    <div key={l} style={{ background: '#F5F0E8', border: '1px solid #E8E0D0', borderRadius: 10, padding: '14px 8px', textAlign: 'center' }}>
                      <div style={{ fontFamily: "'Playfair Display', serif", fontWeight: 700, fontSize: '1.4rem', color: '#2C2420' }}>{v}</div>
                      <div style={{ fontFamily: "'DM Sans', sans-serif", fontSize: 11, color: '#9A8B7E' }}>{l}</div>
                    </div>
                  ))}
                </div>
                <div style={{ fontFamily: "'DM Sans', sans-serif", fontWeight: 600, fontSize: 14, color: '#2C2420', marginBottom: 14 }}>Recent Entries</div>
                {[['A peaceful sunday morning','May 22','Calm'],['Overthinking again','May 21','Anxious'],['Grateful for little things','May 20','Happy']].map(([t,d,m],i) => (
                  <div key={i} style={{
                    display: 'flex', alignItems: 'center', justifyContent: 'space-between',
                    padding: '10px 0', borderBottom: '1px solid rgba(212,201,184,0.4)',
                  }}>
                    <div style={{ display: 'flex', gap: 12, alignItems: 'center' }}>
                      <div style={{ fontFamily: "'Cormorant Garamond', serif", fontSize: '1.1rem', color: '#9A8B7E', fontStyle: 'italic' }}>{i+1}</div>
                      <div>
                        <div style={{ fontFamily: "'Cormorant Garamond', serif", fontStyle: 'italic', fontSize: '0.95rem', color: '#2C2420' }}>{t}</div>
                        <div style={{ fontFamily: "'DM Sans', sans-serif", fontSize: 11, color: '#9A8B7E' }}>{d} · {m}</div>
                      </div>
                    </div>
                    <div style={{ width: 44, height: 44, borderRadius: 6, background: 'linear-gradient(135deg,#D4C9B8,#B8A99A)' }} />
                  </div>
                ))}
              </div>

              {/* Right panel — editor preview */}
              <div style={{ background: '#FAF7F2', borderRadius: 10, padding: '24px 28px', border: '1px solid rgba(212,201,184,0.3)', position: 'relative' }}>
                <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 16 }}>
                  <div style={{ fontFamily: "'DM Sans', sans-serif", fontSize: 13, color: '#9A8B7E' }}>May 22, 2025</div>
                  <div style={{ background: '#2C2420', color: '#FAF7F2', padding: '6px 16px', borderRadius: 6, fontFamily: "'DM Sans', sans-serif", fontSize: 12, fontWeight: 500 }}>Save</div>
                </div>
                <div style={{ fontFamily: "'Cormorant Garamond', serif", fontStyle: 'italic', fontSize: '1.5rem', color: '#2C2420', marginBottom: 16, borderBottom: '1px solid rgba(212,201,184,0.5)', paddingBottom: 10 }}>
                  A peaceful sunday morning
                </div>
                <div style={{ fontFamily: "'Cormorant Garamond', serif", fontSize: '0.97rem', color: '#5C4F44', lineHeight: 1.8, marginBottom: 12 }}>
                  Woke up early today. The air was fresh and everything felt so calm. Made a cup of coffee, sat by the window and just watched the world slow down.
                </div>
                <div style={{ fontFamily: "'Cormorant Garamond', serif", fontSize: '0.97rem', color: '#5C4F44', lineHeight: 1.8 }}>
                  Some days don't have to be productive to be meaningful.
                </div>
                {/* Sticky note in editor */}
                <div style={{
                  position: 'absolute', bottom: 60, right: 20, background: '#F2E8C6',
                  padding: '12px 14px', transform: 'rotate(-1deg)',
                  boxShadow: '2px 4px 10px rgba(44,36,32,0.12)',
                  fontFamily: "'Caveat', cursive", fontSize: 14, color: '#3D3025', lineHeight: 1.5,
                  maxWidth: 130,
                }}>
                  Slow down. You're doing better than you think.
                </div>
                {/* Tags */}
                <div style={{ position: 'absolute', bottom: 20, left: 24, display: 'flex', gap: 6 }}>
                  {['#morning','#peace','#grateful'].map(t => (
                    <span key={t} style={{ padding: '3px 10px', background: '#E8E0D0', borderRadius: 20, fontFamily: "'DM Sans', sans-serif", fontSize: 11, color: '#5C4F44' }}>{t}</span>
                  ))}
                </div>
              </div>
            </div>
          </motion.div>
        </Section>
      </section>

      {/* ─── CTA ────────────────────────────────────────── */}
      <section style={{ padding: '80px 5vw', background: '#FAF7F2', borderTop: '1px solid rgba(212,201,184,0.5)' }}>
        <Section>
          <motion.div variants={fadeUp} style={{ textAlign: 'center', maxWidth: 560, margin: '0 auto' }}>
            <div style={{ fontFamily: "'Cormorant Garamond', serif", fontStyle: 'italic', fontSize: '2.5rem', fontWeight: 500, color: '#2C2420', marginBottom: 16, lineHeight: 1.3 }}>
              Begin your story today.
            </div>
            <div style={{ fontFamily: "'DM Sans', sans-serif", fontSize: 15, color: '#9A8B7E', marginBottom: 32, lineHeight: 1.7 }}>
              Every great memory starts with a single entry. Your visual diary is waiting.
            </div>
            <Link to="/signup" className="btn-primary" style={{ fontSize: 15, padding: '13px 36px' }}>
              Start Writing Free
            </Link>
          </motion.div>
        </Section>
      </section>

      {/* ─── FOOTER ─────────────────────────────────────── */}
      <footer style={{
        background: '#2C2420', color: '#D4C9B8', padding: '48px 5vw',
        display: 'grid', gridTemplateColumns: '1fr auto 1fr', alignItems: 'center', gap: 24,
      }}>
        <div>
          <div style={{ fontFamily: "'Cormorant Garamond', serif", fontStyle: 'italic', fontSize: '1.1rem', color: '#C4A882', marginBottom: 6 }}>
            ❝ Write what should not be forgotten.
          </div>
          <div style={{ fontFamily: "'Cormorant Garamond', serif", fontStyle: 'italic', fontSize: '1.1rem', color: '#C4A882', marginBottom: 4 }}>
            Keep what matters. Let go of what doesn't. ❞
          </div>
          <div style={{ fontFamily: "'Caveat', cursive", fontSize: 16, color: '#9A8B7E' }}>— Unknown</div>
        </div>

        <div style={{ textAlign: 'center' }}>
          <div style={{ fontFamily: "'Playfair Display', serif", fontWeight: 900, fontSize: 18, color: '#F5F0E8', letterSpacing: '-0.01em', lineHeight: 1.1 }}>
            THE<br />VISUAL<br />DIARY
          </div>
        </div>

        <div style={{ textAlign: 'right' }}>
          <div style={{ fontFamily: "'DM Sans', sans-serif", fontSize: 13, color: '#9A8B7E', marginBottom: 12 }}>
            Made with ♡ for dreamers and thinkers like you.
          </div>
          <div style={{ display: 'flex', gap: 16, justifyContent: 'flex-end' }}>
            {[Twitter, Instagram].map((Icon, i) => (
              <a key={i} href="#" style={{ color: '#9A8B7E', transition: 'color 0.2s' }}
                onMouseEnter={e => e.currentTarget.style.color = '#C4A882'}
                onMouseLeave={e => e.currentTarget.style.color = '#9A8B7E'}>
                <Icon size={18} />
              </a>
            ))}
          </div>
        </div>
      </footer>
    </div>
  );
}
