import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { PenSquare, ArrowRight, Heart } from 'lucide-react';
import axios from 'axios';
import AppLayout from '../components/AppLayout';
import { useAuth } from '../context/AuthContext';
import {
  format, parseISO,
  startOfMonth, endOfMonth, eachDayOfInterval, getDay,
} from 'date-fns';

const MOODS = {
  calm:       { emoji: '🌊', color: '#E8F0E8', text: '#4A6B4A' },
  happy:      { emoji: '☀️', color: '#F5EDD8', text: '#7A5C2A' },
  anxious:    { emoji: '🌪️', color: '#F0E8E8', text: '#6B3535' },
  sad:        { emoji: '🌧️', color: '#E8ECF5', text: '#354466' },
  peaceful:   { emoji: '🕊️', color: '#E8EFF0', text: '#2A5C64' },
  grateful:   { emoji: '🌸', color: '#F5E8F0', text: '#642A58' },
  reflective: { emoji: '🌙', color: '#EEE8F5', text: '#4A2A6B' },
  creative:   { emoji: '✨', color: '#F5EEE8', text: '#6B4A2A' },
};

const DAILY_QUOTES = [
  { text: 'Write what should not be forgotten.',                     author: 'Isabel Allende' },
  { text: 'Fill your paper with the breathings of your heart.',      author: 'William Wordsworth' },
  { text: 'I can shake off everything as I write.',                  author: 'Anne Frank' },
  { text: 'Journal writing is a voyage to the interior.',            author: 'Christina Baldwin' },
  { text: 'The act of writing is the act of discovering what you believe.', author: 'David Hare' },
  { text: 'Keep a notebook. Travel with it, eat with it, sleep with it.',   author: 'Jack London' },
  { text: 'In the journal I create myself.',                         author: 'Susan Sontag' },
];

const fadeUp = {
  hidden: { opacity: 0, y: 18 },
  show:   { opacity: 1, y: 0, transition: { duration: 0.55, ease: [0.22,1,0.36,1] } },
};
const stagger = { show: { transition: { staggerChildren: 0.1 } } };

// ─── BUG-11 FIX: safe date formatter ───────────────────────
// parseISO('2025-05-14') → midnight in LOCAL timezone (correct).
// new Date('2025-05-14') → midnight UTC → wrong day in UTC- zones.
function safeFormatDate(dateStr, fmt) {
  if (!dateStr) return '';
  try {
    return format(parseISO(dateStr.split('T')[0]), fmt || 'MMM d, yyyy');
  } catch {
    return dateStr;
  }
}

/* ── Mini Calendar ───────────────────────────────────────── */
function MiniCalendar({ entries }) {
  const today = new Date();
  const [curr, setCurr] = useState(today);
  const days        = eachDayOfInterval({ start: startOfMonth(curr), end: endOfMonth(curr) });
  const startOffset = getDay(startOfMonth(curr));

  // Build a set of 'YYYY-MM-DD' strings that have entries.
  // With dateStrings:true in db.js, entry_date comes back as
  // 'YYYY-MM-DD' already — no T suffix to strip in most cases,
  // but we guard with split() for safety.
  const entryDates = new Set(
    (entries || []).map(e => e.entry_date ? e.entry_date.split('T')[0] : null).filter(Boolean)
  );

  return (
    <div>
      {/* Month navigation */}
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 14 }}>
        <button
          onClick={() => setCurr(d => new Date(d.getFullYear(), d.getMonth()-1, 1))}
          style={{ background: 'none', border: 'none', cursor: 'pointer', color: 'var(--ink-muted)', fontSize: 16, padding: 4 }}
        >‹</button>
        <div style={{ fontFamily: "'DM Sans', sans-serif", fontWeight: 600, fontSize: 13, color: 'var(--ink)' }}>
          {format(curr, 'MMMM yyyy')}
        </div>
        <button
          onClick={() => setCurr(d => new Date(d.getFullYear(), d.getMonth()+1, 1))}
          style={{ background: 'none', border: 'none', cursor: 'pointer', color: 'var(--ink-muted)', fontSize: 16, padding: 4 }}
        >›</button>
      </div>

      {/* Day headers */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(7,1fr)', gap: 2, marginBottom: 6 }}>
        {['Su','Mo','Tu','We','Th','Fr','Sa'].map(d => (
          <div key={d} style={{
            textAlign: 'center', fontFamily: "'DM Sans', sans-serif",
            fontSize: 11, color: 'var(--ink-muted)', padding: '4px 0', fontWeight: 500,
          }}>{d}</div>
        ))}
      </div>

      {/* Day cells */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(7,1fr)', gap: 2 }}>
        {Array(startOffset).fill(null).map((_, i) => <div key={'e' + i} />)}
        {days.map(day => {
          const ds       = format(day, 'yyyy-MM-dd');
          const isToday  = ds === format(today, 'yyyy-MM-dd');
          const hasEntry = entryDates.has(ds);
          return (
            <Link key={ds} to={'/calendar?date=' + ds} style={{ textDecoration: 'none' }}>
              <div style={{
                width: '100%', aspectRatio: '1',
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                borderRadius: '50%', position: 'relative', cursor: hasEntry ? 'pointer' : 'default',
                background:  isToday ? 'var(--ink)' : 'transparent',
                fontFamily: "'DM Sans', sans-serif", fontSize: 12,
                color:       isToday ? 'var(--cream)' : hasEntry ? 'var(--bark)' : 'var(--ink-light)',
                fontWeight:  isToday ? 600 : hasEntry ? 600 : 400,
                transition: 'background 0.15s',
              }}>
                {format(day, 'd')}
                {hasEntry && !isToday && (
                  <div style={{
                    position: 'absolute', bottom: 2, left: '50%', transform: 'translateX(-50%)',
                    width: 4, height: 4, borderRadius: '50%', background: 'var(--bark-light)',
                  }} />
                )}
              </div>
            </Link>
          );
        })}
      </div>
    </div>
  );
}

/* ── Recent Entry Row ────────────────────────────────────── */
function EntryRow({ entry, index }) {
  const navigate = useNavigate();
  const mood = MOODS[entry.mood];
  return (
    <motion.div
      variants={fadeUp}
      onClick={() => navigate('/editor/' + entry.id)}
      style={{
        display: 'flex', alignItems: 'center', gap: 14, padding: '12px 0',
        borderBottom: '1px solid rgba(212,201,184,0.4)', cursor: 'pointer',
      }}
      whileHover={{ paddingLeft: 6, transition: { duration: 0.15 } }}
    >
      <div style={{ fontFamily: "'Cormorant Garamond', serif", fontStyle: 'italic', fontSize: '1.1rem', color: 'var(--bark-light)', width: 20, textAlign: 'center', flexShrink: 0 }}>
        {index + 1}
      </div>
      <div style={{ flex: 1, overflow: 'hidden' }}>
        <div style={{ fontFamily: "'Cormorant Garamond', serif", fontStyle: 'italic', fontSize: '1.05rem', color: 'var(--ink)', marginBottom: 3, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>
          {entry.title || 'Untitled'}
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          {/* BUG-11 FIX: use safeFormatDate instead of new Date() */}
          <span style={{ fontFamily: "'DM Sans', sans-serif", fontSize: 11, color: 'var(--ink-muted)' }}>
            {safeFormatDate(entry.entry_date)}
          </span>
          {mood && (
            <span style={{ fontFamily: "'DM Sans', sans-serif", fontSize: 11, color: mood.text }}>
              · {mood.emoji} {entry.mood}
            </span>
          )}
          {(entry.is_favorite === 1 || entry.is_favorite === true) && (
            <Heart size={11} fill="#C4826A" color="#C4826A" />
          )}
        </div>
      </div>
      {entry.cover_image
        ? (
          <div style={{ width: 44, height: 44, borderRadius: 6, overflow: 'hidden', flexShrink: 0, background: 'var(--parchment)' }}>
            <img
              src={'http://localhost:5000/uploads/' + entry.cover_image}
              alt=""
              style={{ width: '100%', height: '100%', objectFit: 'cover', filter: 'saturate(0.85)' }}
            />
          </div>
        ) : (
          <div style={{ width: 44, height: 44, borderRadius: 6, flexShrink: 0, background: 'linear-gradient(135deg,var(--parchment-dark),var(--bark-light))' }} />
        )
      }
    </motion.div>
  );
}

/* ── MAIN DASHBOARD ─────────────────────────────────────── */
export default function Dashboard() {
  const { user }  = useAuth();
  const navigate  = useNavigate();
  const today     = new Date();

  const [stats,      setStats]      = useState(null);
  const [entries,    setEntries]    = useState([]);
  const [calEntries, setCalEntries] = useState([]);

  const quote = DAILY_QUOTES[today.getDate() % DAILY_QUOTES.length];

  useEffect(() => {
    // Fetch all dashboard data in parallel
    axios.get('/api/entries/stats')
      .then(r => setStats(r.data))
      .catch(() => {});

    axios.get('/api/entries?limit=5')
      .then(r => setEntries(r.data.entries || []))
      .catch(() => {});

    axios.get('/api/entries/calendar?year=' + today.getFullYear() + '&month=' + (today.getMonth() + 1))
      .then(r => setCalEntries(r.data.entries || []))
      .catch(() => {});
  }, []); // eslint-disable-line

  const greeting = () => {
    const h = today.getHours();
    if (h < 12) return 'Good morning';
    if (h < 17) return 'Good afternoon';
    return 'Good evening';
  };

  return (
    <AppLayout>
      <motion.div variants={stagger} initial="hidden" animate="show">

        {/* ── Page header ─────────────────────────────── */}
        <motion.div variants={fadeUp} style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', marginBottom: 32 }}>
          <div>
            <div style={{ fontFamily: "'Cormorant Garamond', serif", fontStyle: 'italic', fontSize: '1rem', color: 'var(--ink-muted)', marginBottom: 4 }}>
              {greeting()},
            </div>
            <div style={{ fontFamily: "'Playfair Display', serif", fontWeight: 700, fontSize: '2rem', color: 'var(--ink)', lineHeight: 1.1, marginBottom: 4 }}>
              {user ? (user.display_name || user.username) : ''}
            </div>
            <div style={{ fontFamily: "'DM Sans', sans-serif", fontSize: 13, color: 'var(--ink-muted)' }}>
              {format(today, 'EEEE, MMMM d, yyyy')}
            </div>
          </div>
          <Link to="/editor" className="btn-primary" style={{ gap: 8, padding: '11px 22px' }}>
            <PenSquare size={15} /> New Entry
          </Link>
        </motion.div>

        {/* ── Stats row ───────────────────────────────── */}
        {stats && (
          <motion.div variants={fadeUp} style={{ display: 'grid', gridTemplateColumns: 'repeat(4,1fr)', gap: 12, marginBottom: 28 }}>
            {[
              { value: stats.totalEntries, label: 'Entries' },
              { value: stats.streak,       label: 'Days Streak' },
              { value: stats.categories,   label: 'Moods Used' },
              {
                value: stats.totalWords >= 1000
                  ? (stats.totalWords / 1000).toFixed(1) + 'k'
                  : stats.totalWords,
                label: 'Words Written',
              },
            ].map(({ value, label }) => (
              <motion.div
                key={label}
                whileHover={{ y: -3 }}
                transition={{ duration: 0.2 }}
                style={{
                  background: 'var(--cream-light)', border: '1px solid rgba(212,201,184,0.5)',
                  borderRadius: 11, padding: '18px 16px', textAlign: 'center',
                }}
              >
                <div style={{ fontFamily: "'Playfair Display', serif", fontWeight: 700, fontSize: '1.8rem', color: 'var(--ink)', lineHeight: 1 }}>
                  {value ?? '–'}
                </div>
                <div style={{ fontFamily: "'DM Sans', sans-serif", fontSize: 11, color: 'var(--ink-muted)', marginTop: 4 }}>
                  {label}
                </div>
              </motion.div>
            ))}
          </motion.div>
        )}

        {/* ── Two-column layout ───────────────────────── */}
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 360px', gap: 20 }}>

          {/* Left column */}
          <div style={{ display: 'flex', flexDirection: 'column', gap: 20 }}>

            {/* Recent entries */}
            <motion.div variants={fadeUp} style={{
              background: 'var(--cream-light)', border: '1px solid rgba(212,201,184,0.45)',
              borderRadius: 12, padding: '24px',
            }}>
              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 8 }}>
                <div style={{ fontFamily: "'Playfair Display', serif", fontWeight: 600, fontSize: '1.15rem', color: 'var(--ink)' }}>
                  Recent Memories
                </div>
                <Link to="/entries" style={{ fontFamily: "'DM Sans', sans-serif", fontSize: 12, color: 'var(--ink-muted)', textDecoration: 'none', display: 'flex', alignItems: 'center', gap: 4 }}>
                  View all <ArrowRight size={12} />
                </Link>
              </div>
              {entries.length === 0 ? (
                <div style={{ textAlign: 'center', padding: '32px 0' }}>
                  <div style={{ fontFamily: "'Cormorant Garamond', serif", fontStyle: 'italic', fontSize: '1.1rem', color: 'var(--ink-muted)', marginBottom: 12 }}>
                    Your diary is waiting for its first story.
                  </div>
                  <Link to="/editor" className="btn-primary" style={{ fontSize: 13, padding: '9px 20px' }}>
                    Write your first entry
                  </Link>
                </div>
              ) : (
                <motion.div variants={stagger} initial="hidden" animate="show">
                  {entries.map((e, i) => <EntryRow key={e.id} entry={e} index={i} />)}
                </motion.div>
              )}
            </motion.div>

            {/* Daily quote */}
            <motion.div variants={fadeUp} style={{
              background: 'var(--parchment)', borderRadius: 10, padding: '22px 24px', position: 'relative', overflow: 'hidden',
            }}>
              <div style={{ position: 'absolute', bottom: -8, right: 12, fontSize: 64, opacity: 0.15 }}>🌿</div>
              <div style={{ fontFamily: "'Cormorant Garamond', serif", fontStyle: 'italic', fontSize: '0.9rem', color: 'var(--ink-muted)', marginBottom: 6, textTransform: 'uppercase', letterSpacing: '0.12em' }}>
                Today's thought
              </div>
              <div style={{ fontFamily: "'Cormorant Garamond', serif", fontStyle: 'italic', fontSize: '1.2rem', color: 'var(--ink)', lineHeight: 1.6, marginBottom: 10, position: 'relative', zIndex: 1 }}>
                "{quote.text}"
              </div>
              <div style={{ fontFamily: "'DM Sans', sans-serif", fontSize: 12, color: 'var(--ink-muted)' }}>
                — {quote.author}
              </div>
            </motion.div>

            {/* Mood summary */}
            {stats && stats.topMoods && stats.topMoods.length > 0 && (
              <motion.div variants={fadeUp} style={{
                background: 'var(--cream-light)', border: '1px solid rgba(212,201,184,0.45)',
                borderRadius: 12, padding: '22px 24px',
              }}>
                <div style={{ fontFamily: "'Playfair Display', serif", fontWeight: 600, fontSize: '1.05rem', color: 'var(--ink)', marginBottom: 16 }}>
                  Your Mood Story
                </div>
                <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8 }}>
                  {stats.topMoods.map(({ mood, count }) => {
                    const m = MOODS[mood];
                    if (!m) return null;
                    return (
                      <div key={mood} style={{
                        display: 'flex', alignItems: 'center', gap: 6,
                        padding: '6px 14px', background: m.color, borderRadius: 20,
                      }}>
                        <span style={{ fontSize: 15 }}>{m.emoji}</span>
                        <span style={{ fontFamily: "'DM Sans', sans-serif", fontSize: 12, color: m.text, fontWeight: 500 }}>{mood}</span>
                        <span style={{ fontFamily: "'DM Sans', sans-serif", fontSize: 11, color: 'var(--ink-muted)' }}>×{count}</span>
                      </div>
                    );
                  })}
                </div>
              </motion.div>
            )}
          </div>

          {/* Right column */}
          <div style={{ display: 'flex', flexDirection: 'column', gap: 20 }}>

            {/* Mini calendar */}
            <motion.div variants={fadeUp} style={{
              background: 'var(--cream-light)', border: '1px solid rgba(212,201,184,0.45)',
              borderRadius: 12, padding: '22px 20px',
            }}>
              <div style={{ fontFamily: "'Playfair Display', serif", fontWeight: 600, fontSize: '1.05rem', color: 'var(--ink)', marginBottom: 18 }}>
                This Month
              </div>
              <MiniCalendar entries={calEntries} />
            </motion.div>

            {/* CTA card */}
            <motion.div
              variants={fadeUp}
              onClick={() => navigate('/editor')}
              whileHover={{ scale: 1.02, boxShadow: '0 8px 28px rgba(44,36,32,0.18)' }}
              style={{
                background: 'var(--ink)', borderRadius: 12, padding: '24px 22px',
                cursor: 'pointer', position: 'relative', overflow: 'hidden',
              }}
            >
              <div style={{ position: 'absolute', top: -20, right: -10, fontSize: 80, opacity: 0.06 }}>✍️</div>
              <div style={{ fontFamily: "'Cormorant Garamond', serif", fontStyle: 'italic', fontSize: '1.3rem', color: 'var(--cream)', marginBottom: 8 }}>
                Ready to write?
              </div>
              <div style={{ fontFamily: "'DM Sans', sans-serif", fontSize: 12, color: 'var(--ink-muted)', marginBottom: 16, lineHeight: 1.6 }}>
                Every word is a step closer to understanding yourself.
              </div>
              <div style={{ display: 'flex', alignItems: 'center', gap: 6, fontFamily: "'DM Sans', sans-serif", fontSize: 13, color: 'var(--bark-light)', fontWeight: 500 }}>
                <PenSquare size={14} /> Open the editor <ArrowRight size={13} />
              </div>
            </motion.div>

          </div>
        </div>
      </motion.div>
    </AppLayout>
  );
}
