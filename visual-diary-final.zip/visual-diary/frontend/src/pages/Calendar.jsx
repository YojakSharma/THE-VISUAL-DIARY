import React, { useState, useEffect } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { ChevronLeft, ChevronRight, PenSquare } from 'lucide-react';
import axios from 'axios';
import {
  format, startOfMonth, endOfMonth, eachDayOfInterval,
  getDay, isSameMonth, isToday, parseISO, isSameDay
} from 'date-fns';
import AppLayout from '../components/AppLayout';

const MOODS = {
  calm:       { emoji: '🌊', color: '#E8F0E8', text: '#4A6B4A' },
  happy:      { emoji: '☀️', color: '#F5EDD8', text: '#7A5C2A' },
  grateful:   { emoji: '🌸', color: '#F5E8F0', text: '#642A58' },
  peaceful:   { emoji: '🕊️', color: '#E8EFF0', text: '#2A5C64' },
  reflective: { emoji: '🌙', color: '#EEE8F5', text: '#4A2A6B' },
  anxious:    { emoji: '🌪️', color: '#F0E8E8', text: '#6B3535' },
  sad:        { emoji: '🌧️', color: '#E8ECF5', text: '#354466' },
  creative:   { emoji: '✨', color: '#F5EEE8', text: '#6B4A2A' },
};

export default function Calendar() {
  const [currMonth, setCurrMonth] = useState(new Date());
  const [entries, setEntries]     = useState([]);
  const [selected, setSelected]   = useState(null);
  const [dayEntries, setDayEntries] = useState([]);
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();

  useEffect(() => {
    const dateParam = searchParams.get('date');
    if (dateParam) {
      const d = parseISO(dateParam);
      setCurrMonth(startOfMonth(d));
      setSelected(d);
    }
  }, []);

  useEffect(() => {
    fetchCalendar();
  }, [currMonth]);

  useEffect(() => {
    if (selected) {
      const ds = format(selected, 'yyyy-MM-dd');
      setDayEntries(entries.filter(e => e.entry_date?.startsWith(ds)));
    } else {
      setDayEntries([]);
    }
  }, [selected, entries]);

  const fetchCalendar = async () => {
    try {
      const { data } = await axios.get('/api/entries/calendar', {
        params: { year: currMonth.getFullYear(), month: currMonth.getMonth() + 1 }
      });
      setEntries(data.entries || []);
    } catch {}
  };

  const days = eachDayOfInterval({ start: startOfMonth(currMonth), end: endOfMonth(currMonth) });
  const startOffset = getDay(startOfMonth(currMonth));

  const prevMonth = () => setCurrMonth(d => new Date(d.getFullYear(), d.getMonth() - 1, 1));
  const nextMonth = () => setCurrMonth(d => new Date(d.getFullYear(), d.getMonth() + 1, 1));

  const entriesForDay = (day) =>
    entries.filter(e => e.entry_date && isSameDay(parseISO(e.entry_date.split('T')[0]), day));

  return (
    <AppLayout>
      <motion.div initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }}>
        {/* Header */}
        <div style={{ display: 'flex', alignItems: 'flex-end', justifyContent: 'space-between', marginBottom: 28 }}>
          <div>
            <div style={{ fontFamily: "'Cormorant Garamond', serif", fontStyle: 'italic', fontSize: '0.95rem', color: 'var(--ink-muted)', marginBottom: 4 }}>Your journey</div>
            <div style={{ fontFamily: "'Playfair Display', serif", fontWeight: 700, fontSize: '1.9rem', color: 'var(--ink)', lineHeight: 1 }}>Memory Calendar</div>
          </div>
          <button onClick={() => navigate('/editor')} className="btn-primary" style={{ gap: 7, fontSize: 13, padding: '9px 18px' }}>
            <PenSquare size={14} /> New Entry
          </button>
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: '1fr 340px', gap: 22, alignItems: 'start' }}>

          {/* ── Calendar ────────────────────────────────── */}
          <div style={{ background: 'var(--cream-light)', borderRadius: 14, padding: '28px 24px', border: '1px solid rgba(212,201,184,0.45)', boxShadow: '0 2px 16px rgba(44,36,32,0.06)' }}>

            {/* Month nav */}
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 24 }}>
              <button onClick={prevMonth} style={{ width: 34, height: 34, borderRadius: 8, border: '1px solid rgba(212,201,184,0.6)', background: 'none', cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'var(--ink-light)', transition: 'background 0.15s' }}
                onMouseEnter={e => e.currentTarget.style.background = 'var(--parchment)'}
                onMouseLeave={e => e.currentTarget.style.background = 'transparent'}>
                <ChevronLeft size={16} />
              </button>
              <div>
                <div style={{ fontFamily: "'Playfair Display', serif", fontWeight: 700, fontSize: '1.5rem', color: 'var(--ink)', textAlign: 'center', lineHeight: 1 }}>
                  {format(currMonth, 'MMMM')}
                </div>
                <div style={{ fontFamily: "'DM Sans', sans-serif", fontSize: 13, color: 'var(--ink-muted)', textAlign: 'center', marginTop: 3 }}>
                  {format(currMonth, 'yyyy')}
                </div>
              </div>
              <button onClick={nextMonth} style={{ width: 34, height: 34, borderRadius: 8, border: '1px solid rgba(212,201,184,0.6)', background: 'none', cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'var(--ink-light)', transition: 'background 0.15s' }}
                onMouseEnter={e => e.currentTarget.style.background = 'var(--parchment)'}
                onMouseLeave={e => e.currentTarget.style.background = 'transparent'}>
                <ChevronRight size={16} />
              </button>
            </div>

            {/* Day headers */}
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(7,1fr)', gap: 4, marginBottom: 8 }}>
              {['Sun','Mon','Tue','Wed','Thu','Fri','Sat'].map(d => (
                <div key={d} style={{ textAlign: 'center', fontFamily: "'DM Sans', sans-serif", fontSize: 11, color: 'var(--parchment-dark)', fontWeight: 500, paddingBottom: 8, borderBottom: '1px solid rgba(212,201,184,0.4)' }}>{d}</div>
              ))}
            </div>

            {/* Days grid */}
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(7,1fr)', gap: 4 }}>
              {Array(startOffset).fill(null).map((_, i) => <div key={`e-${i}`} />)}
              {days.map(day => {
                const dayEnts = entriesForDay(day);
                const today   = isToday(day);
                const isSel   = selected && isSameDay(day, selected);
                const hasMood = dayEnts[0]?.mood;
                const moodStyle = hasMood ? MOODS[hasMood] : null;

                return (
                  <motion.div
                    key={format(day, 'yyyy-MM-dd')}
                    onClick={() => setSelected(isSel ? null : day)}
                    whileHover={{ scale: 1.08 }}
                    whileTap={{ scale: 0.95 }}
                    style={{
                      aspectRatio: '1', display: 'flex', flexDirection: 'column',
                      alignItems: 'center', justifyContent: 'center',
                      borderRadius: 10, cursor: dayEnts.length > 0 ? 'pointer' : 'default',
                      background: isSel
                        ? '#2C2420'
                        : today
                          ? 'rgba(44,36,32,0.08)'
                          : moodStyle
                            ? moodStyle.color
                            : 'transparent',
                      border: today && !isSel ? '1.5px solid rgba(44,36,32,0.25)' : '1.5px solid transparent',
                      transition: 'all 0.2s',
                      position: 'relative',
                      padding: 4,
                    }}
                  >
                    <span style={{
                      fontFamily: "'DM Sans', sans-serif", fontSize: 13, lineHeight: 1,
                      color: isSel ? '#FAF7F2' : today ? '#2C2420' : dayEnts.length > 0 ? (moodStyle?.text || '#2C2420') : '#7A6E65',
                      fontWeight: today || isSel ? 700 : dayEnts.length > 0 ? 600 : 400,
                    }}>
                      {format(day, 'd')}
                    </span>
                    {dayEnts.length > 0 && !isSel && (
                      <div style={{ display: 'flex', gap: 2, marginTop: 2, flexWrap: 'wrap', justifyContent: 'center' }}>
                        {dayEnts.slice(0, 3).map((_, i) => (
                          <div key={i} style={{ width: 4, height: 4, borderRadius: '50%', background: moodStyle?.text || '#C4A882', opacity: 0.7 }} />
                        ))}
                      </div>
                    )}
                    {hasMood && !isSel && (
                      <div style={{ fontSize: 9, marginTop: 1 }}>{MOODS[hasMood]?.emoji}</div>
                    )}
                  </motion.div>
                );
              })}
            </div>

            {/* Legend */}
            <div style={{ marginTop: 20, paddingTop: 16, borderTop: '1px solid rgba(212,201,184,0.4)', display: 'flex', gap: 16, flexWrap: 'wrap' }}>
              {Object.entries(MOODS).map(([id, m]) => (
                <div key={id} style={{ display: 'flex', alignItems: 'center', gap: 5 }}>
                  <div style={{ width: 10, height: 10, borderRadius: 3, background: m.color, border: `1px solid ${m.text}30` }} />
                  <span style={{ fontFamily: "'DM Sans', sans-serif", fontSize: 10, color: 'var(--ink-muted)' }}>{id}</span>
                </div>
              ))}
            </div>
          </div>

          {/* ── Day panel ───────────────────────────────── */}
          <div>
            <AnimatePresence mode="wait">
              {selected ? (
                <motion.div key={format(selected, 'yyyy-MM-dd')}
                  initial={{ opacity: 0, x: 16 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -16 }}
                  transition={{ duration: 0.3 }}
                  style={{ background: 'var(--cream-light)', borderRadius: 14, padding: '24px 22px', border: '1px solid rgba(212,201,184,0.45)', boxShadow: '0 2px 16px rgba(44,36,32,0.06)' }}>

                  {/* Tape decoration */}
                  <div style={{ position: 'relative', marginBottom: 18, display: 'flex', justifyContent: 'center' }}>
                    <div style={{
                      width: 52, height: 19, background: 'rgba(220,198,155,0.52)', borderRadius: 3,
                      position: 'absolute', top: -14, left: '50%', transform: 'translateX(-50%) rotate(-1deg)',
                      boxShadow: '1px 1px 4px rgba(44,36,32,0.10)',
                    }}>
                      <div style={{ position: 'absolute', inset: 0, borderRadius: 3, background: 'repeating-linear-gradient(45deg,transparent,transparent 3px,rgba(255,255,255,0.18) 3px,rgba(255,255,255,0.18) 6px)' }} />
                    </div>
                  </div>

                  <div style={{ fontFamily: "'Cormorant Garamond', serif", fontStyle: 'italic', fontSize: '0.9rem', color: 'var(--ink-muted)', marginBottom: 4 }}>
                    {format(selected, 'EEEE')}
                  </div>
                  <div style={{ fontFamily: "'Playfair Display', serif", fontWeight: 700, fontSize: '1.6rem', color: 'var(--ink)', marginBottom: 20 }}>
                    {format(selected, 'MMMM d, yyyy')}
                  </div>

                  {dayEntries.length === 0 ? (
                    <div style={{ textAlign: 'center', padding: '24px 0' }}>
                      <div style={{ fontSize: 32, marginBottom: 10, opacity: 0.4 }}>✦</div>
                      <div style={{ fontFamily: "'Cormorant Garamond', serif", fontStyle: 'italic', fontSize: '1rem', color: 'var(--ink-muted)', marginBottom: 16, lineHeight: 1.6 }}>
                        No entries for this day.<br />Would you like to add one?
                      </div>
                      <button onClick={() => navigate(`/editor?date=${format(selected, 'yyyy-MM-dd')}`)}
                        className="btn-ghost" style={{ fontSize: 13, padding: '8px 18px' }}>
                        <PenSquare size={13} /> Write for this day
                      </button>
                    </div>
                  ) : (
                    <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
                      {dayEntries.map(entry => {
                        const mood = MOODS[entry.mood];
                        return (
                          <motion.div
                            key={entry.id}
                            initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }}
                            whileHover={{ y: -2 }}
                            onClick={() => navigate(`/editor/${entry.id}`)}
                            style={{
                              padding: '14px 16px', background: '#F5F0E8',
                              borderRadius: 10, border: '1px solid rgba(212,201,184,0.5)',
                              cursor: 'pointer', transition: 'box-shadow 0.2s',
                            }}
                          >
                            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 6 }}>
                              <div style={{ fontFamily: "'Cormorant Garamond', serif", fontStyle: 'italic', fontSize: '1.05rem', color: 'var(--ink)', fontWeight: 500 }}>
                                {entry.title}
                              </div>
                              {mood && (
                                <span style={{ fontSize: 16 }}>{mood.emoji}</span>
                              )}
                            </div>
                            {mood && (
                              <span style={{ fontFamily: "'DM Sans', sans-serif", fontSize: 10, color: mood.text, background: mood.color, padding: '2px 9px', borderRadius: 20 }}>
                                {entry.mood}
                              </span>
                            )}
                          </motion.div>
                        );
                      })}
                    </div>
                  )}
                </motion.div>
              ) : (
                <motion.div key="empty"
                  initial={{ opacity: 0 }} animate={{ opacity: 1 }}
                  style={{ background: 'var(--cream-light)', borderRadius: 14, padding: '40px 22px', border: '1px solid rgba(212,201,184,0.45)', textAlign: 'center' }}>
                  <div style={{ fontSize: 40, marginBottom: 14, opacity: 0.3 }}>📅</div>
                  <div style={{ fontFamily: "'Cormorant Garamond', serif", fontStyle: 'italic', fontSize: '1.05rem', color: 'var(--ink-muted)', lineHeight: 1.6 }}>
                    Select a day to view<br />your memories
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </div>
      </motion.div>
    </AppLayout>
  );
}
