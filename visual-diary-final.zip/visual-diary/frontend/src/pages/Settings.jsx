import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Save, Check } from 'lucide-react';
import axios from 'axios';
import AppLayout from '../components/AppLayout';
import { useAuth } from '../context/AuthContext';
import { applyTheme } from '../utils/theme';

// ── Theme + font definitions (mirrors utils/theme.js for the UI) ──
const THEMES = [
  { id: 'vintage-paper',   name: 'Vintage Paper',   bg: '#F5F0E8', textColor: '#2C2420', accent: '#8B7355', preview: ['#F5F0E8','#E8E0D0','#8B7355'], desc: 'Warm aged paper' },
  { id: 'soft-beige',      name: 'Soft Beige',      bg: '#FAF6F0', textColor: '#3D3530', accent: '#C4A882', preview: ['#FAF6F0','#F0E8D8','#C4A882'], desc: 'Gentle cream' },
  { id: 'dotted-notebook', name: 'Dotted Notebook', bg: '#FAFAFA', textColor: '#2D2D2D', accent: '#6B8F71', preview: ['#FAFAFA','#F0F0F0','#6B8F71'], desc: 'Classic journal' },
  { id: 'minimal-white',   name: 'Minimal White',   bg: '#FFFFFF', textColor: '#1A1A1A', accent: '#B0927A', preview: ['#FFFFFF','#F5F5F5','#B0927A'], desc: 'Clean & modern' },
  { id: 'dark-journal',    name: 'Dark Journal',    bg: '#1C1917', textColor: '#F5F0E8', accent: '#C4A882', preview: ['#1C1917','#2C2824','#C4A882'], desc: 'Moody nights' },
];

const FONT_SIZES = [
  { id: 'small',  label: 'Small',  sample: '13px' },
  { id: 'medium', label: 'Medium', sample: '15px' },
  { id: 'large',  label: 'Large',  sample: '17px' },
];

const fadeUp = { hidden: { opacity: 0, y: 16 }, show: { opacity: 1, y: 0, transition: { duration: 0.5 } } };
const stagger = { show: { transition: { staggerChildren: 0.08 } } };

function Section({ title, subtitle, children }) {
  return (
    <motion.div variants={fadeUp} style={{
      background: 'var(--cream-light)', borderRadius: 14, padding: '24px 26px',
      border: '1px solid rgba(212,201,184,0.45)', marginBottom: 18,
    }}>
      <div style={{ marginBottom: 18, paddingBottom: 14, borderBottom: '1px solid rgba(212,201,184,0.4)' }}>
        <div style={{ fontFamily: "'Playfair Display', serif", fontWeight: 600, fontSize: '1.1rem', color: 'var(--ink)' }}>{title}</div>
        {subtitle && <div style={{ fontFamily: "'DM Sans', sans-serif", fontSize: 12, color: 'var(--ink-muted)', marginTop: 3 }}>{subtitle}</div>}
      </div>
      {children}
    </motion.div>
  );
}

function Toggle({ value, onChange, label, desc }) {
  return (
    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '10px 0' }}>
      <div>
        <div style={{ fontFamily: "'DM Sans', sans-serif", fontSize: 14, color: 'var(--ink)', fontWeight: 500 }}>{label}</div>
        {desc && <div style={{ fontFamily: "'DM Sans', sans-serif", fontSize: 12, color: 'var(--ink-muted)', marginTop: 2 }}>{desc}</div>}
      </div>
      <button
        onClick={() => onChange(!value)}
        style={{
          width: 44, height: 24, borderRadius: 12, border: 'none', cursor: 'pointer',
          background: value ? 'var(--ink)' : 'var(--parchment-dark)',
          position: 'relative', transition: 'background 0.25s', flexShrink: 0,
        }}
      >
        <div style={{
          position: 'absolute', top: 3, width: 18, height: 18, borderRadius: '50%',
          background: 'white', transition: 'left 0.25s', left: value ? 23 : 3,
          boxShadow: '0 1px 4px rgba(44,36,32,0.2)',
        }} />
      </button>
    </div>
  );
}

export default function Settings() {
  const { user, updateUser, updateSettings } = useAuth();
  const [form, setForm]  = useState({
    theme: 'vintage-paper', font_size: 'medium',
    notifications_enabled: true, auto_save_interval: 30, public_profile: false,
  });
  const [passwords, setPasswords] = useState({ current_password: '', new_password: '', confirm: '' });
  const [msg,    setMsg]    = useState({ type: '', text: '' });
  const [saving, setSaving] = useState(false);

  // ── BUG-04 FIX: load saved settings and apply them when this page mounts ──
  // Previously: settings were loaded into local state but applyTheme() was
  //   never called, so the theme had no visual effect even on this page.
  // Now: immediately apply on load so user sees their current selection.
  useEffect(() => {
    axios.get('/api/settings')
      .then(({ data }) => {
        if (data && data.settings) {
          const s = data.settings;
          setForm(prev => ({ ...prev, ...s }));
          // Apply on load so the Settings page itself reflects the saved theme
          applyTheme(s.theme || 'vintage-paper', s.font_size || 'medium');
        }
      })
      .catch(() => {});
  }, []);

  const showMsg = (type, text) => {
    setMsg({ type, text });
    setTimeout(() => setMsg({ type: '', text: '' }), 3000);
  };

  // ── BUG-04 FIX: live preview when selecting a theme card ──
  // Clicking a theme card now immediately calls applyTheme() so
  // the user sees the colour change BEFORE hitting Save Settings.
  const selectTheme = (themeId) => {
    setForm(prev => ({ ...prev, theme: themeId }));
    applyTheme(themeId, form.font_size); // instant live preview
  };

  // ── BUG-04 FIX: live preview when selecting font size ──
  const selectFontSize = (sizeId) => {
    setForm(prev => ({ ...prev, font_size: sizeId }));
    applyTheme(form.theme, sizeId); // instant live preview
  };

  const saveSettings = async () => {
    setSaving(true);
    try {
      await axios.put('/api/settings', form);
      // Update AuthContext so other pages stay in sync
      updateUser({ theme: form.theme });
      updateSettings({ theme: form.theme, font_size: form.font_size });
      // Re-apply to confirm (handles any async drift)
      applyTheme(form.theme, form.font_size);
      showMsg('success', 'Settings saved successfully!');
    } catch {
      showMsg('error', 'Failed to save settings.');
    }
    setSaving(false);
  };

  const changePassword = async () => {
    if (passwords.new_password !== passwords.confirm) {
      showMsg('error', 'Passwords do not match.');
      return;
    }
    if (passwords.new_password.length < 6) {
      showMsg('error', 'Password must be at least 6 characters.');
      return;
    }
    setSaving(true);
    try {
      await axios.put('/api/profile/password', {
        current_password: passwords.current_password,
        new_password:     passwords.new_password,
      });
      setPasswords({ current_password: '', new_password: '', confirm: '' });
      showMsg('success', 'Password updated!');
    } catch (err) {
      showMsg('error', (err.response && err.response.data && err.response.data.error) || 'Failed to change password.');
    }
    setSaving(false);
  };

  const currentTheme = THEMES.find(t => t.id === form.theme) || THEMES[0];

  return (
    <AppLayout>
      <motion.div variants={stagger} initial="hidden" animate="show">

        {/* Header */}
        <motion.div variants={fadeUp} style={{ marginBottom: 28 }}>
          <div style={{ fontFamily: "'Cormorant Garamond', serif", fontStyle: 'italic', fontSize: '0.95rem', color: 'var(--ink-muted)', marginBottom: 4 }}>Preferences</div>
          <div style={{ fontFamily: "'Playfair Display', serif", fontWeight: 700, fontSize: '1.9rem', color: 'var(--ink)', lineHeight: 1 }}>Settings</div>
        </motion.div>

        {/* Message banner */}
        {msg.text && (
          <motion.div
            initial={{ opacity: 0, y: -8 }} animate={{ opacity: 1, y: 0 }}
            style={{
              marginBottom: 18, padding: '12px 18px', borderRadius: 10,
              background: msg.type === 'success' ? '#E8F0E8' : '#F5E8E8',
              border: '1px solid ' + (msg.type === 'success' ? '#C4D8C4' : '#D4AAAA'),
              fontFamily: "'DM Sans', sans-serif", fontSize: 13,
              color: msg.type === 'success' ? '#4A6B4A' : '#6B3535',
              display: 'flex', alignItems: 'center', gap: 8,
            }}
          >
            {msg.type === 'success' ? <Check size={14} /> : '!'} {msg.text}
          </motion.div>
        )}

        {/* ── Appearance ──────────────────────────────── */}
        <Section title="Appearance" subtitle="Choose how your diary looks and feels">

          <div style={{ fontFamily: "'DM Sans', sans-serif", fontSize: 12, fontWeight: 500, color: 'var(--ink-light)', letterSpacing: '0.07em', textTransform: 'uppercase', marginBottom: 12 }}>
            Theme
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(5,1fr)', gap: 10 }}>
            {THEMES.map(t => (
              <motion.button
                key={t.id}
                onClick={() => selectTheme(t.id)}
                whileHover={{ y: -3 }}
                whileTap={{ scale: 0.97 }}
                style={{
                  padding: 0, cursor: 'pointer', overflow: 'hidden', background: 'none',
                  border: '2px solid ' + (form.theme === t.id ? 'var(--ink)' : 'rgba(212,201,184,0.5)'),
                  borderRadius: 10,
                  boxShadow: form.theme === t.id ? '0 0 0 3px rgba(44,36,32,0.12)' : 'none',
                  transition: 'all 0.2s',
                }}
                title={t.desc}
              >
                {/* Colour swatch preview */}
                <div style={{ display: 'flex', height: 48 }}>
                  {t.preview.map((c, i) => (
                    <div key={i} style={{ flex: 1, background: c }} />
                  ))}
                </div>
                <div style={{ padding: '8px 8px 10px', background: t.bg }}>
                  <div style={{ fontFamily: "'DM Sans', sans-serif", fontSize: 11, fontWeight: 600, color: t.textColor, textAlign: 'center' }}>
                    {t.name}
                  </div>
                  {form.theme === t.id && (
                    <div style={{ display: 'flex', justifyContent: 'center', marginTop: 4 }}>
                      <div style={{ width: 6, height: 6, borderRadius: '50%', background: t.accent }} />
                    </div>
                  )}
                </div>
              </motion.button>
            ))}
          </div>

          {/* Font Size */}
          <div style={{ marginTop: 20, paddingTop: 18, borderTop: '1px solid rgba(212,201,184,0.4)' }}>
            <div style={{ fontFamily: "'DM Sans', sans-serif", fontSize: 12, fontWeight: 500, color: 'var(--ink-light)', letterSpacing: '0.07em', textTransform: 'uppercase', marginBottom: 10 }}>
              Font Size
            </div>
            <div style={{ display: 'flex', gap: 10 }}>
              {FONT_SIZES.map(f => (
                <button
                  key={f.id}
                  onClick={() => selectFontSize(f.id)}
                  style={{
                    padding: '8px 20px', borderRadius: 8, cursor: 'pointer',
                    border: '1.5px solid ' + (form.font_size === f.id ? 'var(--ink)' : 'rgba(212,201,184,0.6)'),
                    background: form.font_size === f.id ? 'var(--ink)' : 'transparent',
                    color:      form.font_size === f.id ? 'var(--cream)' : 'var(--ink-light)',
                    fontFamily: "'DM Sans', sans-serif", fontSize: f.sample,
                    transition: 'all 0.2s',
                  }}
                >
                  {f.label}
                </button>
              ))}
            </div>
            <div style={{ fontFamily: "'DM Sans', sans-serif", fontSize: 11, color: 'var(--ink-muted)', marginTop: 8 }}>
              Font size affects all diary text. Changes preview instantly.
            </div>
          </div>
        </Section>

        {/* ── Writing experience ───────────────────────── */}
        <Section title="Writing Experience" subtitle="Customise how you write">
          <div style={{ display: 'flex', flexDirection: 'column' }}>
            <Toggle label="Auto-save entries" desc="Automatically save drafts while writing" value={true} onChange={() => {}} />
            <div style={{ height: 1, background: 'rgba(212,201,184,0.4)' }} />
            <Toggle
              label="Daily reminder" desc="Get a gentle nudge to write every day"
              value={!!form.notifications_enabled}
              onChange={v => setForm(f => ({ ...f, notifications_enabled: v }))}
            />
            <div style={{ height: 1, background: 'rgba(212,201,184,0.4)' }} />
            <Toggle
              label="Public profile" desc="Let others see your profile page"
              value={!!form.public_profile}
              onChange={v => setForm(f => ({ ...f, public_profile: v }))}
            />
          </div>
          <div style={{ marginTop: 16, paddingTop: 16, borderTop: '1px solid rgba(212,201,184,0.4)' }}>
            <label style={{ fontFamily: "'DM Sans', sans-serif", fontSize: 12, fontWeight: 500, color: 'var(--ink-light)', letterSpacing: '0.07em', textTransform: 'uppercase', display: 'block', marginBottom: 8 }}>
              Auto-save interval
            </label>
            <div style={{ display: 'flex', gap: 8 }}>
              {[15, 30, 60].map(v => (
                <button
                  key={v}
                  onClick={() => setForm(f => ({ ...f, auto_save_interval: v }))}
                  style={{
                    padding: '6px 16px', borderRadius: 7, cursor: 'pointer',
                    border: '1.5px solid ' + (form.auto_save_interval === v ? 'var(--ink)' : 'rgba(212,201,184,0.6)'),
                    background: form.auto_save_interval === v ? 'var(--ink)' : 'transparent',
                    color:      form.auto_save_interval === v ? 'var(--cream)' : 'var(--ink-light)',
                    fontFamily: "'DM Sans', sans-serif", fontSize: 13, transition: 'all 0.2s',
                  }}
                >
                  {v}s
                </button>
              ))}
            </div>
          </div>
        </Section>

        {/* ── Account ─────────────────────────────────── */}
        <Section title="Account" subtitle="Your account details">
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 14, marginBottom: 14 }}>
            <div>
              <label style={{ fontFamily: "'DM Sans', sans-serif", fontSize: 11, fontWeight: 500, color: 'var(--ink-light)', letterSpacing: '0.07em', textTransform: 'uppercase', display: 'block', marginBottom: 5 }}>Email</label>
              <input value={user ? user.email : ''} disabled className="paper-input" style={{ fontSize: 13, opacity: 0.7, cursor: 'not-allowed' }} />
            </div>
            <div>
              <label style={{ fontFamily: "'DM Sans', sans-serif", fontSize: 11, fontWeight: 500, color: 'var(--ink-light)', letterSpacing: '0.07em', textTransform: 'uppercase', display: 'block', marginBottom: 5 }}>Username</label>
              <input value={user ? user.username : ''} disabled className="paper-input" style={{ fontSize: 13, opacity: 0.7, cursor: 'not-allowed' }} />
            </div>
          </div>
          <div style={{ fontFamily: "'DM Sans', sans-serif", fontSize: 12, color: 'var(--ink-muted)' }}>
            To change your name or username, visit your <a href="/profile" style={{ color: 'var(--bark)' }}>Profile page</a>.
          </div>
        </Section>

        {/* ── Change Password ──────────────────────────── */}
        <Section title="Change Password" subtitle="Keep your diary secure">
          <div style={{ display: 'flex', flexDirection: 'column', gap: 12, maxWidth: 400 }}>
            {[
              { label: 'Current Password', key: 'current_password', placeholder: 'Your current password' },
              { label: 'New Password',     key: 'new_password',     placeholder: 'Min. 6 characters' },
              { label: 'Confirm New',      key: 'confirm',          placeholder: 'Repeat new password' },
            ].map(({ label, key, placeholder }) => (
              <div key={key}>
                <label style={{ fontFamily: "'DM Sans', sans-serif", fontSize: 11, fontWeight: 500, color: 'var(--ink-light)', letterSpacing: '0.07em', textTransform: 'uppercase', display: 'block', marginBottom: 5 }}>
                  {label}
                </label>
                <input
                  type="password"
                  value={passwords[key]}
                  onChange={e => setPasswords(p => ({ ...p, [key]: e.target.value }))}
                  placeholder={placeholder}
                  className="paper-input"
                  style={{ fontSize: 13 }}
                />
              </div>
            ))}
            <button
              onClick={changePassword}
              disabled={saving}
              className="btn-ghost"
              style={{ alignSelf: 'flex-start', fontSize: 13, marginTop: 4 }}
            >
              Update Password
            </button>
          </div>
        </Section>

        {/* ── Save button ──────────────────────────────── */}
        <motion.div variants={fadeUp} style={{ display: 'flex', justifyContent: 'flex-end' }}>
          <button
            onClick={saveSettings}
            disabled={saving}
            className="btn-primary"
            style={{ gap: 8, fontSize: 14, padding: '12px 28px' }}
          >
            <Save size={14} /> {saving ? 'Saving...' : 'Save Settings'}
          </button>
        </motion.div>

      </motion.div>
    </AppLayout>
  );
}
