import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Eye, EyeOff } from 'lucide-react';
import { useAuth } from '../context/AuthContext';

const Tape = () => (
  <div style={{
    position: 'absolute', top: -10, left: '50%', transform: 'translateX(-50%)',
    width: 56, height: 20, background: 'rgba(220,198,155,0.55)', borderRadius: 3, zIndex: 1,
    boxShadow: '1px 1px 4px rgba(44,36,32,0.10)',
  }}>
    <div style={{ position: 'absolute', inset: 0, borderRadius: 3, background: 'repeating-linear-gradient(45deg,transparent,transparent 3px,rgba(255,255,255,0.18) 3px,rgba(255,255,255,0.18) 6px)' }} />
  </div>
);

export default function Signup() {
  const [form, setForm] = useState({ username: '', email: '', display_name: '', password: '' });
  const [showPass, setShowPass] = useState(false);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const { signup } = useAuth();
  const navigate = useNavigate();

  const set = (k) => (e) => setForm(prev => ({ ...prev, [k]: e.target.value }));

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError(''); setLoading(true);
    try {
      await signup(form);
      navigate('/dashboard');
    } catch (err) {
      setError(err.response?.data?.error || 'Something went wrong.');
    } finally { setLoading(false); }
  };

  return (
    <div style={{ minHeight: '100vh', background: '#F5F0E8', display: 'flex', alignItems: 'center', justifyContent: 'center', padding: '40px 20px', position: 'relative', overflow: 'hidden' }}>
      <motion.div animate={{ rotate: [0, 4, 0, -4, 0] }} transition={{ duration: 12, repeat: Infinity }}
        style={{ position: 'fixed', top: '6%', right: '5%', fontSize: 72, opacity: 0.08, pointerEvents: 'none' }}>🌿</motion.div>
      <motion.div animate={{ rotate: [0, -3, 0, 3, 0] }} transition={{ duration: 9, repeat: Infinity, delay: 2 }}
        style={{ position: 'fixed', bottom: '8%', left: '4%', fontSize: 56, opacity: 0.08, pointerEvents: 'none' }}>🌸</motion.div>

      <Link to="/" style={{
        position: 'fixed', top: 24, left: 28, zIndex: 10,
        fontFamily: "'DM Sans', sans-serif", fontSize: 13, color: '#9A8B7E', textDecoration: 'none',
      }}>← THE VISUAL DIARY</Link>

      <motion.div initial={{ opacity: 0, y: 24 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.7, ease: [0.22,1,0.36,1] }}>
        <div style={{
          background: '#FAF7F2', borderRadius: 14, padding: '48px 44px',
          boxShadow: '0 8px 40px rgba(44,36,32,0.12)', width: '100%', maxWidth: 440, position: 'relative',
        }}>
          <Tape />
          <div style={{ textAlign: 'center', marginBottom: 32 }}>
            <div style={{ fontFamily: "'Playfair Display', serif", fontWeight: 900, fontSize: 22, color: '#2C2420', lineHeight: 1.1, marginBottom: 10 }}>
              THE<br />VISUAL DIARY
            </div>
            <div style={{ width: 40, height: 1.5, background: '#C4A882', margin: '0 auto 12px' }} />
            <div style={{ fontFamily: "'Cormorant Garamond', serif", fontStyle: 'italic', fontSize: '1.15rem', color: '#5C4F44' }}>
              Begin your story
            </div>
          </div>

          {error && (
            <div style={{ background: '#F5E8E8', border: '1px solid #D4AAAA', borderRadius: 8, padding: '10px 14px', marginBottom: 20, fontFamily: "'DM Sans', sans-serif", fontSize: 13, color: '#6B3535' }}>
              {error}
            </div>
          )}

          <form onSubmit={handleSubmit} style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
            {[
              { label: 'Your Name', key: 'display_name', type: 'text', placeholder: 'What shall we call you?' },
              { label: 'Username', key: 'username', type: 'text', placeholder: 'your_handle' },
              { label: 'Email', key: 'email', type: 'email', placeholder: 'your@email.com' },
            ].map(({ label, key, type, placeholder }) => (
              <div key={key}>
                <label style={{ fontFamily: "'DM Sans', sans-serif", fontSize: 11, fontWeight: 500, color: '#5C4F44', letterSpacing: '0.07em', textTransform: 'uppercase', display: 'block', marginBottom: 5 }}>
                  {label}
                </label>
                <input type={type} value={form[key]} onChange={set(key)} required
                  className="paper-input" placeholder={placeholder} />
              </div>
            ))}
            <div>
              <label style={{ fontFamily: "'DM Sans', sans-serif", fontSize: 11, fontWeight: 500, color: '#5C4F44', letterSpacing: '0.07em', textTransform: 'uppercase', display: 'block', marginBottom: 5 }}>
                Password
              </label>
              <div style={{ position: 'relative' }}>
                <input type={showPass ? 'text' : 'password'} value={form.password} onChange={set('password')} required
                  className="paper-input" placeholder="Min. 6 characters" style={{ paddingRight: 44 }} />
                <button type="button" onClick={() => setShowPass(!showPass)}
                  style={{ position: 'absolute', right: 12, top: '50%', transform: 'translateY(-50%)', background: 'none', border: 'none', cursor: 'pointer', color: '#9A8B7E', display: 'flex' }}>
                  {showPass ? <EyeOff size={16} /> : <Eye size={16} />}
                </button>
              </div>
            </div>

            <button type="submit" disabled={loading} className="btn-primary" style={{ marginTop: 6, width: '100%', justifyContent: 'center', fontSize: 15, padding: '13px' }}>
              {loading ? 'Creating your diary...' : 'Create My Diary'}
            </button>
          </form>

          <div style={{ textAlign: 'center', marginTop: 20 }}>
            <span style={{ fontFamily: "'DM Sans', sans-serif", fontSize: 13, color: '#9A8B7E' }}>Already have one? </span>
            <Link to="/login" style={{ fontFamily: "'DM Sans', sans-serif", fontSize: 13, color: '#8B7355', fontWeight: 500, textDecoration: 'none' }}>
              Open your diary →
            </Link>
          </div>
        </div>
      </motion.div>
    </div>
  );
}
