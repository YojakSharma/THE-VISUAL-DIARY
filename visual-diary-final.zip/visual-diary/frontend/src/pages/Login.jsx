import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Eye, EyeOff } from 'lucide-react';
import { useAuth } from '../context/AuthContext';

const Tape = ({ className = '' }) => (
  <div className={`absolute z-10 ${className}`} style={{
    width: 56, height: 20,
    background: 'rgba(220,198,155,0.55)',
    borderRadius: 3,
    boxShadow: '1px 1px 4px rgba(44,36,32,0.10)',
  }}>
    <div style={{ position: 'absolute', inset: 0, borderRadius: 3,
      background: 'repeating-linear-gradient(45deg,transparent,transparent 3px,rgba(255,255,255,0.18) 3px,rgba(255,255,255,0.18) 6px)' }} />
  </div>
);

export default function Login() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPass, setShowPass] = useState(false);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const { login } = useAuth();
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError(''); setLoading(true);
    try {
      await login(email, password);
      navigate('/dashboard');
    } catch (err) {
      setError(err.response?.data?.error || 'Something went wrong.');
    } finally { setLoading(false); }
  };

  return (
    <div style={{ minHeight: '100vh', background: '#F5F0E8', display: 'flex', alignItems: 'center', justifyContent: 'center', padding: '40px 20px', position: 'relative', overflow: 'hidden' }}>

      {/* Background botanical elements */}
      <motion.div animate={{ rotate: [0, 5, 0, -5, 0] }} transition={{ duration: 10, repeat: Infinity }}
        style={{ position: 'fixed', top: '8%', left: '5%', fontSize: 80, opacity: 0.1, pointerEvents: 'none' }}>🌿</motion.div>
      <motion.div animate={{ rotate: [0, -4, 0, 4, 0] }} transition={{ duration: 13, repeat: Infinity, delay: 3 }}
        style={{ position: 'fixed', bottom: '10%', right: '6%', fontSize: 64, opacity: 0.1, pointerEvents: 'none' }}>🌸</motion.div>

      {/* Back to home */}
      <Link to="/" style={{
        position: 'fixed', top: 24, left: 28, zIndex: 10,
        fontFamily: "'DM Sans', sans-serif", fontSize: 13, color: '#9A8B7E', textDecoration: 'none',
        display: 'flex', alignItems: 'center', gap: 6, transition: 'color 0.2s',
      }}
        onMouseEnter={e => e.currentTarget.style.color = '#2C2420'}
        onMouseLeave={e => e.currentTarget.style.color = '#9A8B7E'}
      >
        ← THE VISUAL DIARY
      </Link>

      <motion.div initial={{ opacity: 0, y: 24 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.7, ease: [0.22,1,0.36,1] }}>

        {/* Paper card */}
        <div style={{
          background: '#FAF7F2', borderRadius: 14, padding: '48px 44px',
          boxShadow: '0 8px 40px rgba(44,36,32,0.12), 0 2px 8px rgba(44,36,32,0.06)',
          width: '100%', maxWidth: 420, position: 'relative',
        }}>
          <Tape style={{ top: -10, left: '50%', transform: 'translateX(-50%)' }} />

          {/* Header */}
          <div style={{ textAlign: 'center', marginBottom: 36 }}>
            <div style={{ fontFamily: "'Playfair Display', serif", fontWeight: 900, fontSize: 22, color: '#2C2420', letterSpacing: '-0.01em', lineHeight: 1.1, marginBottom: 10 }}>
              THE<br />VISUAL DIARY
            </div>
            <div style={{ width: 40, height: 1.5, background: '#C4A882', margin: '0 auto 12px' }} />
            <div style={{ fontFamily: "'Cormorant Garamond', serif", fontStyle: 'italic', fontSize: '1.15rem', color: '#5C4F44' }}>
              Welcome back
            </div>
          </div>

          {/* Decorative quote */}
          <div style={{ background: '#F2E8C6', borderRadius: 4, padding: '12px 16px', marginBottom: 28, position: 'relative', transform: 'rotate(-0.5deg)' }}>
            <Tape style={{ top: -10, left: 20 }} />
            <div style={{ fontFamily: "'Caveat', cursive", fontSize: 16, color: '#3D3025', lineHeight: 1.5 }}>
              The pages you write today become the memories of tomorrow.
            </div>
          </div>

          {error && (
            <div style={{ background: '#F5E8E8', border: '1px solid #D4AAAA', borderRadius: 8, padding: '10px 14px', marginBottom: 20, fontFamily: "'DM Sans', sans-serif", fontSize: 13, color: '#6B3535' }}>
              {error}
            </div>
          )}

          <form onSubmit={handleSubmit} style={{ display: 'flex', flexDirection: 'column', gap: 18 }}>
            <div>
              <label style={{ fontFamily: "'DM Sans', sans-serif", fontSize: 12, fontWeight: 500, color: '#5C4F44', letterSpacing: '0.06em', textTransform: 'uppercase', display: 'block', marginBottom: 6 }}>
                Email
              </label>
              <input type="email" value={email} onChange={e => setEmail(e.target.value)} required
                className="paper-input" placeholder="your@email.com" />
            </div>
            <div>
              <label style={{ fontFamily: "'DM Sans', sans-serif", fontSize: 12, fontWeight: 500, color: '#5C4F44', letterSpacing: '0.06em', textTransform: 'uppercase', display: 'block', marginBottom: 6 }}>
                Password
              </label>
              <div style={{ position: 'relative' }}>
                <input type={showPass ? 'text' : 'password'} value={password} onChange={e => setPassword(e.target.value)} required
                  className="paper-input" placeholder="Your password" style={{ paddingRight: 44 }} />
                <button type="button" onClick={() => setShowPass(!showPass)}
                  style={{ position: 'absolute', right: 12, top: '50%', transform: 'translateY(-50%)', background: 'none', border: 'none', cursor: 'pointer', color: '#9A8B7E', display: 'flex' }}>
                  {showPass ? <EyeOff size={16} /> : <Eye size={16} />}
                </button>
              </div>
            </div>

            <button type="submit" disabled={loading} className="btn-primary" style={{ marginTop: 8, width: '100%', justifyContent: 'center', fontSize: 15, padding: '13px' }}>
              {loading ? 'Opening your diary...' : 'Open My Diary'}
            </button>
          </form>

          <div style={{ textAlign: 'center', marginTop: 24 }}>
            <span style={{ fontFamily: "'DM Sans', sans-serif", fontSize: 13, color: '#9A8B7E' }}>New here? </span>
            <Link to="/signup" style={{ fontFamily: "'DM Sans', sans-serif", fontSize: 13, color: '#8B7355', fontWeight: 500, textDecoration: 'none' }}>
              Start your diary →
            </Link>
          </div>
        </div>
      </motion.div>
    </div>
  );
}
