import React, { useState, useEffect, useRef, useCallback } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Bold, Italic, Underline, Quote, Image,
  Save, ArrowLeft, Heart, X, Plus, CheckCircle, Loader, Hash
} from 'lucide-react';
import axios from 'axios';
import { format, parseISO } from 'date-fns';
import AppLayout from '../components/AppLayout';

const MOODS = [
  { id: 'calm',       emoji: '🌊', label: 'Calm',       color: '#E8F0E8', text: '#4A6B4A' },
  { id: 'happy',      emoji: '☀️', label: 'Happy',      color: '#F5EDD8', text: '#7A5C2A' },
  { id: 'grateful',   emoji: '🌸', label: 'Grateful',   color: '#F5E8F0', text: '#642A58' },
  { id: 'peaceful',   emoji: '🕊️', label: 'Peaceful',   color: '#E8EFF0', text: '#2A5C64' },
  { id: 'reflective', emoji: '🌙', label: 'Reflective', color: '#EEE8F5', text: '#4A2A6B' },
  { id: 'anxious',    emoji: '🌪️', label: 'Anxious',    color: '#F0E8E8', text: '#6B3535' },
  { id: 'sad',        emoji: '🌧️', label: 'Sad',        color: '#E8ECF5', text: '#354466' },
  { id: 'creative',   emoji: '✨', label: 'Creative',   color: '#F5EEE8', text: '#6B4A2A' },
];

const PAPER_MODES = [
  { id: 'dotted', label: 'Dotted', bg: 'radial-gradient(circle, rgba(139,115,85,0.18) 1px, transparent 1px)', size: '24px 24px' },
  { id: 'lined',  label: 'Lined',  bg: 'repeating-linear-gradient(to bottom, transparent, transparent 27px, rgba(139,115,85,0.13) 27px, rgba(139,115,85,0.13) 28px)', size: 'auto' },
  { id: 'grid',   label: 'Grid',   bg: 'linear-gradient(rgba(139,115,85,0.10) 1px,transparent 1px),linear-gradient(90deg,rgba(139,115,85,0.10) 1px,transparent 1px)', size: '24px 24px' },
  { id: 'plain',  label: 'Plain',  bg: 'none', size: 'auto' },
];

// Tape strip decoration (used on polaroid images)
const Tape = ({ rotate = 0, width = 56 }) => (
  <div style={{
    width, height: 21,
    background: 'rgba(220,198,155,0.52)',
    transform: 'rotate(' + rotate + 'deg)',
    borderRadius: 3,
    boxShadow: '1px 1px 4px rgba(44,36,32,0.10)',
    flexShrink: 0,
    position: 'relative',
  }}>
    <div style={{
      position: 'absolute', inset: 0, borderRadius: 3,
      background: 'repeating-linear-gradient(45deg,transparent,transparent 3px,rgba(255,255,255,0.16) 3px,rgba(255,255,255,0.16) 6px)',
    }} />
  </div>
);

// Polaroid-style pinned image
function PinnedImage({ src, onRemove, rotate }) {
  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.85, rotate: rotate - 8 }}
      animate={{ opacity: 1, scale: 1, rotate }}
      exit={{ opacity: 0, scale: 0.8 }}
      whileHover={{ scale: 1.04, zIndex: 20 }}
      style={{ position: 'relative', display: 'inline-block' }}
    >
      <div style={{ position: 'absolute', top: -10, left: '50%', transform: 'translateX(-50%)', zIndex: 2 }}>
        <Tape width={44} rotate={-1} />
      </div>
      <div style={{
        background: '#FFFDF8', padding: '8px 8px 30px 8px',
        boxShadow: '4px 6px 18px rgba(44,36,32,0.18), 0 1px 4px rgba(44,36,32,0.08)',
      }}>
        <img
          src={src}
          alt="journal"
          style={{ display: 'block', width: 160, height: 160, objectFit: 'cover', filter: 'saturate(0.88) contrast(1.02)' }}
        />
      </div>
      <button
        onClick={onRemove}
        style={{
          position: 'absolute', top: -6, right: -6, width: 22, height: 22,
          borderRadius: '50%', background: '#2C2420', color: '#FAF7F2',
          border: 'none', cursor: 'pointer', display: 'flex',
          alignItems: 'center', justifyContent: 'center', zIndex: 10,
        }}
      >
        <X size={11} />
      </button>
    </motion.div>
  );
}

// ─── Safe date display helper ─────────────────────────────────
// BUG-11 FIX: parseISO treats 'YYYY-MM-DD' as local midnight.
// new Date('YYYY-MM-DD') treats it as UTC midnight — wrong on
// computers in UTC- timezones (off-by-one day).
function safeFormatDate(dateStr) {
  if (!dateStr) return format(new Date(), 'yyyy-MM-dd');
  try {
    var clean = dateStr.split('T')[0];
    return format(parseISO(clean), 'yyyy-MM-dd');
  } catch {
    return dateStr;
  }
}

// ─── MAIN EDITOR ─────────────────────────────────────────────
export default function Editor() {
  const { id }     = useParams();
  const navigate   = useNavigate();

  const [title,     setTitle]     = useState('');
  const [content,   setContent]   = useState('');
  const [mood,      setMood]      = useState('');
  const [tags,      setTags]      = useState([]);
  const [tagInput,  setTagInput]  = useState('');
  const [images,    setImages]    = useState([]);       // [{ url, id }]
  const [entryDate, setEntryDate] = useState(format(new Date(), 'yyyy-MM-dd'));
  const [paperMode, setPaperMode] = useState('dotted');
  const [isDraft,   setIsDraft]   = useState(false);
  const [isFav,     setIsFav]     = useState(false);

  const [saveStatus,      setSaveStatus]      = useState('idle'); // idle|saving|saved|error
  const [showMoodPicker,  setShowMoodPicker]  = useState(false);
  const [showTagInput,    setShowTagInput]    = useState(false);
  const [uploadingImage,  setUploadingImage]  = useState(false);

  const autoSaveTimer = useRef(null);
  const fileInputRef  = useRef(null);
  const savedIdRef    = useRef(id ? String(id) : null);

  // ── Load existing entry ─────────────────────────────────────
  useEffect(() => {
    if (id) {
      axios.get('/api/entries/' + id)
        .then(({ data }) => {
          const e = data.entry;
          setTitle(e.title || '');
          setContent(e.content || '');
          setMood(e.mood || '');
          setTags(Array.isArray(e.tags) ? e.tags : []);
          setEntryDate(safeFormatDate(e.entry_date));
          setIsDraft(e.is_draft === 1 || e.is_draft === true);
          setIsFav(e.is_favorite === 1 || e.is_favorite === true);
          if (Array.isArray(e.images) && e.images.length > 0) {
            setImages(e.images.map(img => ({
              url: 'http://localhost:5000' + img.file_path,
              id:  img.id,
            })));
          }
        })
        .catch(() => navigate('/entries'));
    }
  }, [id]); // eslint-disable-line

  // ── Save entry (both manual and autosave) ───────────────────
  // useCallback so autosave effect can list it as a dependency
  // without going stale.
  //
  // BUG-09 FIX: previously saveEntry was listed in useCallback
  //   deps but NOT in the autosave useEffect deps. If entryDate
  //   or isFav changed without title/content changing, the
  //   autosave used a stale closure with the old values.
  // Fix: add saveEntry to the autosave useEffect dep array below.
  const saveEntry = useCallback(async (asDraft) => {
    // asDraft defaults to current isDraft state when not specified
    const draftValue = (asDraft !== undefined) ? asDraft : isDraft;
    if (!title.trim() && !content.trim()) return;

    setSaveStatus('saving');
    try {
      const payload = {
        title:      title || 'Untitled',
        content,
        mood,
        tags,
        entry_date: entryDate,
        is_draft:   draftValue,
        is_favorite: isFav,
      };

      if (savedIdRef.current) {
        // Update existing entry
        await axios.put('/api/entries/' + savedIdRef.current, payload);
      } else {
        // Create new entry — store the returned ID for subsequent saves
        const { data } = await axios.post('/api/entries', payload);
        savedIdRef.current = String(data.entryId);
      }
      setSaveStatus('saved');
      setTimeout(() => setSaveStatus('idle'), 2000);
    } catch (err) {
      console.error('Save failed:', err);
      setSaveStatus('error');
      setTimeout(() => setSaveStatus('idle'), 3000);
    }
  }, [title, content, mood, tags, entryDate, isDraft, isFav]);

  // ── Autosave: 4-second debounce ─────────────────────────────
  // BUG-09 FIX: added `saveEntry` to deps array.
  // Now the timer uses the latest version of saveEntry that
  // includes the current entryDate, isDraft, and isFav values.
  useEffect(() => {
    clearTimeout(autoSaveTimer.current);
    autoSaveTimer.current = setTimeout(() => {
      if (title.trim() || content.trim()) {
        saveEntry(true); // autosave always as draft
      }
    }, 4000);
    return () => clearTimeout(autoSaveTimer.current);
  }, [title, content, mood, tags, entryDate, isDraft, isFav, saveEntry]);

  // ── Tag management ──────────────────────────────────────────
  const addTag = () => {
    const t = tagInput.trim().replace(/^#/, '');
    if (t && !tags.includes(t)) setTags(prev => [...prev, t]);
    setTagInput('');
    setShowTagInput(false);
  };

  // ── Image upload ────────────────────────────────────────────
  // BUG FIX (image persistence): previously images uploaded to a
  //   NEW (unsaved) entry had entry_id = NULL in the database.
  //   When the entry was later saved and reloaded, those images
  //   were not linked and appeared to be lost.
  // Fix: if no entry ID exists yet, save the entry FIRST to get
  //   an ID, then upload the image with that ID.
  const handleImageUpload = async (e) => {
    const file = e.target.files ? e.target.files[0] : null;
    if (!file) return;

    setUploadingImage(true);

    // Step 1 — ensure we have an entry ID before uploading
    if (!savedIdRef.current && (title.trim() || content.trim())) {
      try {
        await saveEntry(true); // creates entry, sets savedIdRef.current
      } catch {
        // Continue anyway — image will have entry_id = null
      }
    }

    // Step 2 — upload the image
    const fd = new FormData();
    fd.append('image', file);
    if (savedIdRef.current) {
      fd.append('entry_id', savedIdRef.current);
    }

    try {
      const { data } = await axios.post('/api/profile/upload-image', fd, {
        headers: { 'Content-Type': 'multipart/form-data' },
      });
      setImages(prev => [...prev, {
        url: 'http://localhost:5000' + data.path,
        id:  data.imageId,
      }]);
    } catch (err) {
      console.error('Image upload failed:', err);
      alert('Image upload failed. Please try again.');
    }

    setUploadingImage(false);
    e.target.value = ''; // reset file input
  };

  // Derived values
  const pm           = PAPER_MODES.find(p => p.id === paperMode) || PAPER_MODES[0];
  const selectedMood = MOODS.find(m => m.id === mood);
  const wordCount    = content.trim() ? content.trim().split(/\s+/).length : 0;

  return (
    <AppLayout>
      <div style={{ maxWidth: 860, margin: '0 auto' }}>

        {/* ── Top bar ──────────────────────────────────── */}
        <motion.div
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 24 }}
        >
          <button
            onClick={() => navigate(-1)}
            style={{
              display: 'flex', alignItems: 'center', gap: 7,
              background: 'none', border: 'none', cursor: 'pointer',
              fontFamily: "'DM Sans', sans-serif", fontSize: 13,
              color: 'var(--ink-muted)', padding: '6px 0',
            }}
          >
            <ArrowLeft size={15} /> Back
          </button>

          <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
            {/* Date picker */}
            <input
              type="date"
              value={entryDate}
              onChange={e => setEntryDate(e.target.value)}
              style={{
                fontFamily: "'DM Sans', sans-serif", fontSize: 13,
                color: 'var(--ink-muted)', background: 'none',
                border: 'none', cursor: 'pointer', outline: 'none',
              }}
            />

            {/* Save status indicator */}
            <AnimatePresence mode="wait">
              {saveStatus === 'saving' && (
                <motion.span key="saving"
                  initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
                  style={{ display: 'flex', alignItems: 'center', gap: 5, fontFamily: "'DM Sans', sans-serif", fontSize: 12, color: 'var(--ink-muted)' }}>
                  <Loader size={13} style={{ animation: 'spin 1s linear infinite' }} /> Saving…
                </motion.span>
              )}
              {saveStatus === 'saved' && (
                <motion.span key="saved"
                  initial={{ opacity: 0, scale: 0.8 }} animate={{ opacity: 1, scale: 1 }} exit={{ opacity: 0 }}
                  style={{ display: 'flex', alignItems: 'center', gap: 5, fontFamily: "'DM Sans', sans-serif", fontSize: 12, color: '#4A6B4A' }}>
                  <CheckCircle size={13} /> Saved
                </motion.span>
              )}
              {saveStatus === 'error' && (
                <motion.span key="error"
                  initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
                  style={{ fontFamily: "'DM Sans', sans-serif", fontSize: 12, color: '#8B3535' }}>
                  Save failed
                </motion.span>
              )}
            </AnimatePresence>

            {/* Favourite toggle */}
            <button
              onClick={() => setIsFav(f => !f)}
              style={{
                background: 'none', border: 'none', cursor: 'pointer',
                padding: 4, display: 'flex',
                color: isFav ? '#C4826A' : 'var(--parchment-dark)',
                transition: 'color 0.2s',
              }}
              title={isFav ? 'Remove from favorites' : 'Add to favorites'}
            >
              <Heart size={17} fill={isFav ? 'currentColor' : 'none'} />
            </button>

            {/* Manual save */}
            <button
              onClick={() => saveEntry(false)}
              style={{
                display: 'flex', alignItems: 'center', gap: 7,
                background: 'var(--ink)', color: 'var(--cream)',
                border: 'none', padding: '9px 20px', borderRadius: 8,
                fontFamily: "'DM Sans', sans-serif", fontSize: 13, fontWeight: 500,
                cursor: 'pointer', transition: 'opacity 0.2s',
              }}
            >
              <Save size={13} /> Save
            </button>
          </div>
        </motion.div>

        {/* ── Paper page ───────────────────────────────── */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, ease: [0.22, 1, 0.36, 1] }}
          style={{
            background: 'var(--cream-light)',
            backgroundImage: pm.bg,
            backgroundSize: pm.size,
            borderRadius: 14,
            boxShadow: 'var(--paper-shadow-lg)',
            padding: '52px 72px',
            position: 'relative',
            minHeight: 700,
          }}
        >
          {/* Paper grain overlay */}
          <div style={{
            position: 'absolute', inset: 0, pointerEvents: 'none', borderRadius: 14,
            backgroundImage: "url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='200' height='200'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.75' numOctaves='4' stitchTiles='stitch'/%3E%3CfeColorMatrix type='saturate' values='0'/%3E%3C/filter%3E%3Crect width='200' height='200' filter='url(%23n)' opacity='0.03'/%3E%3C/svg%3E\")",
            backgroundSize: '180px 180px', mixBlendMode: 'multiply', opacity: 0.7, zIndex: 0,
          }} />

          <div style={{ position: 'relative', zIndex: 1 }}>

            {/* Mood badge */}
            {selectedMood && (
              <motion.div
                initial={{ opacity: 0, x: 10 }}
                animate={{ opacity: 1, x: 0 }}
                style={{
                  position: 'absolute', top: 0, right: 0,
                  display: 'flex', alignItems: 'center', gap: 6,
                  padding: '5px 12px', background: selectedMood.color,
                  borderRadius: 20, fontFamily: "'DM Sans', sans-serif",
                  fontSize: 12, color: selectedMood.text, fontWeight: 500,
                }}
              >
                <span>{selectedMood.emoji}</span> {selectedMood.label}
                <button
                  onClick={() => setMood('')}
                  style={{ background: 'none', border: 'none', cursor: 'pointer', color: 'inherit', display: 'flex', padding: 0, marginLeft: 2 }}
                >
                  <X size={11} />
                </button>
              </motion.div>
            )}

            {/* Title */}
            <div style={{ borderBottom: '1px solid rgba(212,201,184,0.5)', paddingBottom: 16, marginBottom: 20 }}>
              <input
                value={title}
                onChange={e => setTitle(e.target.value)}
                placeholder="Begin with a title..."
                style={{
                  width: '100%', border: 'none', outline: 'none', background: 'transparent',
                  fontFamily: "'Cormorant Garamond', serif", fontStyle: 'italic',
                  fontSize: '2.2rem', fontWeight: 500, color: 'var(--ink)', lineHeight: 1.2,
                  caretColor: 'var(--bark)',
                }}
              />
            </div>

            {/* Pinned images */}
            <AnimatePresence>
              {images.length > 0 && (
                <motion.div
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: 'auto' }}
                  exit={{ opacity: 0, height: 0 }}
                  style={{ display: 'flex', gap: 28, flexWrap: 'wrap', marginBottom: 32, paddingTop: 10 }}
                >
                  {images.map((img, i) => (
                    <PinnedImage
                      key={img.id || i}
                      src={img.url}
                      rotate={[-3, 2, -1.5, 3, -2.5][i % 5]}
                      onRemove={() => setImages(prev => prev.filter((_, idx) => idx !== i))}
                    />
                  ))}
                  {uploadingImage && (
                    <div style={{
                      width: 176, height: 198,
                      background: 'var(--parchment)', borderRadius: 4,
                      display: 'flex', alignItems: 'center', justifyContent: 'center',
                      fontFamily: "'DM Sans', sans-serif", fontSize: 12, color: 'var(--ink-muted)',
                    }}>
                      Uploading…
                    </div>
                  )}
                </motion.div>
              )}
            </AnimatePresence>

            {/* Body */}
            <textarea
              value={content}
              onChange={e => setContent(e.target.value)}
              placeholder="Write what's on your mind… let the words find their own path."
              style={{
                width: '100%', border: 'none', outline: 'none', background: 'transparent',
                fontFamily: "'Cormorant Garamond', serif",
                fontSize: '1.15rem', fontWeight: 400, lineHeight: 1.9,
                color: 'var(--ink-light)', resize: 'none', minHeight: 320,
                caretColor: 'var(--bark)',
              }}
              rows={Math.max(12, content.split('\n').length + 5)}
            />

            {/* Decorative sticky note (appears after 200 chars) */}
            {content.length > 200 && (
              <motion.div
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: 0.3 }}
                style={{
                  position: 'absolute', bottom: 80, right: 48,
                  background: '#F2E8C6', padding: '14px 16px', maxWidth: 170,
                  boxShadow: '2px 4px 12px rgba(44,36,32,0.12)',
                  transform: 'rotate(-1.5deg)', zIndex: 5,
                }}
              >
                <div style={{ position: 'absolute', top: -10, left: '50%', transform: 'translateX(-50%)' }}>
                  <Tape width={44} />
                </div>
                <div style={{ fontFamily: "'Caveat', cursive", fontSize: 15, color: '#3D3025', lineHeight: 1.55 }}>
                  Keep going. Every word matters. ✨
                </div>
              </motion.div>
            )}

            {/* Tags row */}
            <div style={{
              marginTop: 24, paddingTop: 16,
              borderTop: '1px solid rgba(212,201,184,0.4)',
              display: 'flex', alignItems: 'center', flexWrap: 'wrap', gap: 7,
            }}>
              <Hash size={14} style={{ color: 'var(--bark-light)', flexShrink: 0 }} />
              {tags.map(t => (
                <motion.div
                  key={t}
                  initial={{ scale: 0.8, opacity: 0 }}
                  animate={{ scale: 1, opacity: 1 }}
                  style={{
                    display: 'flex', alignItems: 'center', gap: 4,
                    padding: '3px 11px', background: 'var(--parchment)',
                    borderRadius: 20, fontFamily: "'DM Sans', sans-serif",
                    fontSize: 12, color: 'var(--ink-light)', border: '1px solid var(--parchment-dark)',
                  }}
                >
                  #{t}
                  <button
                    onClick={() => setTags(prev => prev.filter(x => x !== t))}
                    style={{ background: 'none', border: 'none', cursor: 'pointer', color: 'var(--ink-muted)', display: 'flex', padding: 0, marginLeft: 2 }}
                  >
                    <X size={10} />
                  </button>
                </motion.div>
              ))}
              <AnimatePresence>
                {showTagInput ? (
                  <motion.input
                    key="tag-input"
                    initial={{ width: 0, opacity: 0 }}
                    animate={{ width: 100, opacity: 1 }}
                    exit={{ width: 0, opacity: 0 }}
                    autoFocus
                    value={tagInput}
                    onChange={e => setTagInput(e.target.value)}
                    onKeyDown={e => {
                      if (e.key === 'Enter')  addTag();
                      if (e.key === 'Escape') setShowTagInput(false);
                    }}
                    onBlur={addTag}
                    placeholder="add tag…"
                    style={{
                      border: 'none', borderBottom: '1px solid var(--bark-light)',
                      outline: 'none', background: 'transparent',
                      fontFamily: "'DM Sans', sans-serif", fontSize: 12,
                      color: 'var(--ink)', padding: '2px 4px',
                    }}
                  />
                ) : (
                  <button
                    onClick={() => setShowTagInput(true)}
                    style={{
                      display: 'flex', alignItems: 'center', gap: 3,
                      padding: '3px 10px', background: 'transparent',
                      border: '1px dashed var(--bark-light)', borderRadius: 20,
                      fontFamily: "'DM Sans', sans-serif", fontSize: 12,
                      color: 'var(--ink-muted)', cursor: 'pointer',
                    }}
                  >
                    <Plus size={11} /> tag
                  </button>
                )}
              </AnimatePresence>
            </div>

          </div>
        </motion.div>

        {/* ── Floating toolbar ─────────────────────────── */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          style={{
            position: 'fixed', bottom: 32, left: '50%', transform: 'translateX(-50%)',
            display: 'flex', alignItems: 'center', gap: 0,
            background: 'var(--cream-light)', border: '1px solid rgba(212,201,184,0.6)',
            borderRadius: 14, padding: '6px 10px',
            boxShadow: '0 8px 32px rgba(44,36,32,0.14), 0 2px 8px rgba(44,36,32,0.08)',
            backdropFilter: 'blur(16px)', zIndex: 50,
          }}
        >
          {/* Paper mode selector */}
          <div style={{ display: 'flex', gap: 2, paddingRight: 8, borderRight: '1px solid rgba(212,201,184,0.5)', marginRight: 8 }}>
            {PAPER_MODES.map(p => (
              <button
                key={p.id}
                onClick={() => setPaperMode(p.id)}
                title={p.label}
                style={{
                  padding: '6px 9px', borderRadius: 7, border: 'none', cursor: 'pointer',
                  background:  paperMode === p.id ? 'var(--parchment)' : 'transparent',
                  fontFamily: "'DM Sans', sans-serif", fontSize: 10,
                  color:       paperMode === p.id ? 'var(--ink)' : 'var(--ink-muted)',
                  fontWeight:  paperMode === p.id ? 600 : 400,
                  letterSpacing: '0.03em', transition: 'all 0.15s',
                }}
              >
                {p.label}
              </button>
            ))}
          </div>

          {/* Format buttons */}
          {[
            { Icon: Bold,      tip: 'Bold' },
            { Icon: Italic,    tip: 'Italic' },
            { Icon: Underline, tip: 'Underline' },
            { Icon: Quote,     tip: 'Quote' },
          ].map(({ Icon, tip }) => (
            <button
              key={tip}
              title={tip}
              style={{
                width: 34, height: 34, display: 'flex', alignItems: 'center', justifyContent: 'center',
                borderRadius: 7, border: 'none', cursor: 'pointer',
                background: 'transparent', color: 'var(--ink-light)', transition: 'all 0.15s',
              }}
              onMouseEnter={e => { e.currentTarget.style.background = 'var(--parchment)'; }}
              onMouseLeave={e => { e.currentTarget.style.background = 'transparent'; }}
            >
              <Icon size={15} />
            </button>
          ))}

          <div style={{ width: 1, height: 22, background: 'rgba(212,201,184,0.6)', margin: '0 6px' }} />

          {/* Mood picker */}
          <div style={{ position: 'relative' }}>
            <button
              onClick={() => setShowMoodPicker(p => !p)}
              title="Set mood"
              style={{
                width: 34, height: 34, display: 'flex', alignItems: 'center', justifyContent: 'center',
                borderRadius: 7, border: 'none', cursor: 'pointer',
                background: showMoodPicker ? 'var(--parchment)' : 'transparent',
                fontSize: 16, transition: 'all 0.15s',
              }}
            >
              {selectedMood ? selectedMood.emoji : '😶'}
            </button>
            <AnimatePresence>
              {showMoodPicker && (
                <motion.div
                  initial={{ opacity: 0, y: 8, scale: 0.95 }}
                  animate={{ opacity: 1, y: 0, scale: 1 }}
                  exit={{ opacity: 0, y: 8, scale: 0.95 }}
                  transition={{ duration: 0.2 }}
                  style={{
                    position: 'absolute', bottom: '110%', left: '50%', transform: 'translateX(-50%)',
                    background: 'var(--cream-light)', border: '1px solid rgba(212,201,184,0.6)',
                    borderRadius: 12, padding: '12px',
                    boxShadow: '0 8px 28px rgba(44,36,32,0.14)',
                    display: 'grid', gridTemplateColumns: 'repeat(4,1fr)', gap: 4, width: 200,
                    zIndex: 60,
                  }}
                >
                  {MOODS.map(m => (
                    <button
                      key={m.id}
                      onClick={() => { setMood(m.id); setShowMoodPicker(false); }}
                      style={{
                        display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 2,
                        padding: '8px 4px', borderRadius: 8, border: 'none', cursor: 'pointer',
                        background: mood === m.id ? m.color : 'transparent',
                        transition: 'background 0.15s',
                      }}
                      onMouseEnter={e => { if (mood !== m.id) e.currentTarget.style.background = 'var(--parchment)'; }}
                      onMouseLeave={e => { if (mood !== m.id) e.currentTarget.style.background = 'transparent'; }}
                    >
                      <span style={{ fontSize: 18 }}>{m.emoji}</span>
                      <span style={{ fontFamily: "'DM Sans', sans-serif", fontSize: 9, color: 'var(--ink-light)' }}>{m.label}</span>
                    </button>
                  ))}
                </motion.div>
              )}
            </AnimatePresence>
          </div>

          {/* Image upload */}
          <button
            onClick={() => fileInputRef.current && fileInputRef.current.click()}
            title="Add image (polaroid)"
            disabled={uploadingImage}
            style={{
              width: 34, height: 34, display: 'flex', alignItems: 'center', justifyContent: 'center',
              borderRadius: 7, border: 'none', cursor: uploadingImage ? 'not-allowed' : 'pointer',
              background: 'transparent', color: uploadingImage ? 'var(--ink-muted)' : 'var(--ink-light)',
              transition: 'all 0.15s',
            }}
            onMouseEnter={e => { if (!uploadingImage) e.currentTarget.style.background = 'var(--parchment)'; }}
            onMouseLeave={e => { e.currentTarget.style.background = 'transparent'; }}
          >
            <Image size={15} />
          </button>
          <input
            ref={fileInputRef}
            type="file"
            accept="image/*"
            onChange={handleImageUpload}
            style={{ display: 'none' }}
          />

          <div style={{ width: 1, height: 22, background: 'rgba(212,201,184,0.6)', margin: '0 6px' }} />

          {/* Draft toggle */}
          <button
            onClick={() => setIsDraft(d => !d)}
            style={{
              padding: '5px 12px', borderRadius: 7,
              border: '1px solid rgba(212,201,184,0.6)',
              cursor: 'pointer', fontFamily: "'DM Sans', sans-serif",
              fontSize: 11, fontWeight: 500,
              background: isDraft ? '#F0E8D0' : 'transparent',
              color:      isDraft ? '#7A5C2A' : 'var(--ink-muted)',
              transition: 'all 0.15s',
            }}
          >
            {isDraft ? 'Draft' : 'Published'}
          </button>

          {/* Word count */}
          <div style={{ padding: '0 8px', fontFamily: "'DM Sans', sans-serif", fontSize: 11, color: 'var(--ink-muted)' }}>
            {wordCount}w
          </div>
        </motion.div>

        {/* Bottom spacer so content isn't hidden behind toolbar */}
        <div style={{ height: 80 }} />
      </div>

      <style>{`
        @keyframes spin { from { transform: rotate(0deg); } to { transform: rotate(360deg); } }
      `}</style>
    </AppLayout>
  );
}
