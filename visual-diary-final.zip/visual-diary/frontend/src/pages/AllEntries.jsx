import React, { useState, useEffect } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { Search, PenSquare, Heart, X, SlidersHorizontal } from 'lucide-react';
import axios from 'axios';
import { format, parseISO } from 'date-fns';
import AppLayout from '../components/AppLayout';

const MOODS = {
  calm:       { emoji: '🌊', color: '#E8F0E8', text: '#4A6B4A' },
  happy:      { emoji: '☀️', color: '#F5EDD8', text: '#7A5C2A' },
  grateful:   { emoji: '🌸', color: '#F5E8F0', text: '#642A58' },
  peaceful:   { emoji: '🕊️', color: '#E8EFF0', text: '#2A5C64' },
  reflective: { emoji: '🌙', color: '#EEE8F5', text: '#4A2A6B' },
  anxious:    { emoji: '🌪️', color: '#F0E8E8', text: '#6B3535' },
  sad:        { emoji: '🌧️', color: '#E8ECF5', text: '#354466' },
  creative:   { emoji: '✨', color: '#F5EEE8', text: '#6B4A2A' },
};
const MOOD_LIST = Object.keys(MOODS);

const fadeUp = {
  hidden: { opacity: 0, y: 16 },
  show:   { opacity: 1, y: 0, transition: { duration: 0.5, ease: [0.22,1,0.36,1] } }
};
const stagger = { show: { transition: { staggerChildren: 0.07 } } };

// ─── Helper: safe date formatting ───────────────────────────
// BUG-11 FIX: use parseISO() instead of new Date() for date-only
// strings. parseISO('2025-05-14') treats it as LOCAL midnight,
// while new Date('2025-05-14') treats it as UTC midnight — which
// shows as the previous day on computers in UTC- timezones.
function formatEntryDate(dateStr) {
  if (!dateStr) return '';
  try {
    // dateStrings:true in db.js gives us 'YYYY-MM-DD' — strip any T suffix
    var clean = dateStr.split('T')[0];
    return format(parseISO(clean), 'MMM d, yyyy');
  } catch {
    return dateStr;
  }
}

/* ── Entry Card ───────────────────────────────────────────── */
// Added:
//   - onFavorite prop  (BUG-07 FIX — quick toggle from list)
//   - Heart toggle button that calls PATCH /api/entries/:id/favorite
function EntryCard({ entry, onDelete, onFavorite }) {
  const navigate = useNavigate();
  const mood     = MOODS[entry.mood];
  const preview  = entry.content ? entry.content.replace(/<[^>]+>/g, '').slice(0, 140) : '';
  const tags     = entry.tags ? entry.tags.split(',').filter(Boolean) : [];
  const isFav    = entry.is_favorite === 1 || entry.is_favorite === true;

  // Delete handler — stops card click from firing
  const handleDelete = async (e) => {
    e.stopPropagation();
    if (!window.confirm('Delete "' + (entry.title || 'this entry') + '"?')) return;
    try {
      await axios.delete('/api/entries/' + entry.id);
      onDelete(entry.id);
    } catch {
      alert('Could not delete entry. Please try again.');
    }
  };

  // ── BUG-07 FIX: favorite toggle ──────────────────────────
  // Previously no endpoint existed. Now calls PATCH /api/entries/:id/favorite
  // and tells the parent (AllEntries) to flip is_favorite in local state.
  const handleFavorite = async (e) => {
    e.stopPropagation(); // prevent navigating to editor
    try {
      const { data } = await axios.patch('/api/entries/' + entry.id + '/favorite');
      onFavorite(entry.id, data.is_favorite);
    } catch {
      // Silently ignore — UX stays consistent
    }
  };

  return (
    <motion.article
      variants={fadeUp}
      onClick={() => navigate('/editor/' + entry.id)}
      whileHover={{ y: -4, boxShadow: '0 10px 36px rgba(44,36,32,0.12)' }}
      style={{
        background: 'var(--cream-light)', borderRadius: 12, overflow: 'hidden',
        border: '1px solid rgba(212,201,184,0.45)', cursor: 'pointer',
        transition: 'box-shadow 0.25s', position: 'relative',
        boxShadow: '0 2px 12px rgba(44,36,32,0.06)',
      }}
    >
      {/* Cover image */}
      {entry.cover_image && (
        <div style={{ height: 140, overflow: 'hidden', background: 'var(--parchment)', position: 'relative' }}>
          <img
            src={'http://localhost:5000/uploads/' + entry.cover_image}
            alt=""
            style={{ width: '100%', height: '100%', objectFit: 'cover',
              filter: 'saturate(0.82) contrast(1.02)', transition: 'transform 0.4s ease' }}
          />
          <div style={{ position: 'absolute', inset: 0,
            background: 'linear-gradient(to bottom, transparent 50%, rgba(250,247,242,0.9) 100%)' }} />
        </div>
      )}

      {/* No image — mood colour accent bar */}
      {!entry.cover_image && (
        <div style={{
          height: 6,
          background: mood
            ? 'linear-gradient(90deg, ' + mood.color + ', transparent)'
            : 'linear-gradient(90deg, rgba(196,168,130,0.3), transparent)',
        }} />
      )}

      <div style={{ padding: '18px 20px 16px' }}>
        {/* Row: date + mood badge + favourite heart */}
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 8 }}>
          <div style={{ fontFamily: "'DM Sans', sans-serif", fontSize: 11, color: 'var(--ink-muted)' }}>
            {formatEntryDate(entry.entry_date)}
          </div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
            {/* ── BUG-07 FIX: clickable heart button ── */}
            <button
              onClick={handleFavorite}
              title={isFav ? 'Remove from favorites' : 'Add to favorites'}
              style={{
                background: 'none', border: 'none', cursor: 'pointer', padding: '2px 4px',
                display: 'flex', alignItems: 'center',
                color: isFav ? '#C4826A' : 'var(--parchment-dark)',
                transition: 'color 0.2s', borderRadius: 4,
              }}
            >
              <Heart size={13} fill={isFav ? 'currentColor' : 'none'} />
            </button>
            {mood && (
              <span style={{
                fontFamily: "'DM Sans', sans-serif", fontSize: 11,
                color: mood.text, background: mood.color,
                padding: '2px 8px', borderRadius: 20,
              }}>
                {mood.emoji} {entry.mood}
              </span>
            )}
          </div>
        </div>

        {/* Title */}
        <div style={{
          fontFamily: "'Cormorant Garamond', serif", fontStyle: 'italic',
          fontSize: '1.2rem', fontWeight: 500, color: 'var(--ink)',
          marginBottom: 8, lineHeight: 1.3,
          display: '-webkit-box', WebkitLineClamp: 2, WebkitBoxOrient: 'vertical', overflow: 'hidden',
        }}>
          {entry.title || 'Untitled'}
        </div>

        {/* Preview */}
        {preview && (
          <div style={{
            fontFamily: "'Cormorant Garamond', serif", fontSize: '0.95rem',
            color: 'var(--ink-light)', lineHeight: 1.65, marginBottom: 12,
            display: '-webkit-box', WebkitLineClamp: 3, WebkitBoxOrient: 'vertical', overflow: 'hidden',
          }}>
            {preview}
          </div>
        )}

        {/* Tags */}
        {tags.length > 0 && (
          <div style={{ display: 'flex', flexWrap: 'wrap', gap: 5, marginBottom: 10 }}>
            {tags.slice(0, 3).map(t => (
              <span key={t} style={{
                fontFamily: "'DM Sans', sans-serif", fontSize: 10, color: 'var(--bark)',
                background: 'var(--parchment)', padding: '2px 9px', borderRadius: 20,
                border: '1px solid rgba(212,201,184,0.5)',
              }}>#{t}</span>
            ))}
          </div>
        )}

        {/* Footer row: word count, draft badge, delete button */}
        <div style={{
          display: 'flex', alignItems: 'center', justifyContent: 'space-between',
          paddingTop: 10, borderTop: '1px solid rgba(212,201,184,0.35)',
        }}>
          <div style={{ fontFamily: "'DM Sans', sans-serif", fontSize: 11, color: 'var(--ink-muted)' }}>
            {entry.word_count ? entry.word_count + ' words' : ''}
            {(entry.is_draft === 1 || entry.is_draft === true) && (
              <span style={{
                marginLeft: 8, padding: '1px 7px',
                background: '#F0E8D0', borderRadius: 10, color: '#8B7355', fontSize: 10,
              }}>Draft</span>
            )}
          </div>
          <button
            onClick={handleDelete}
            style={{
              background: 'none', border: 'none', cursor: 'pointer',
              fontFamily: "'DM Sans', sans-serif", fontSize: 11, color: '#C4A8A8',
              padding: '2px 6px', borderRadius: 4, transition: 'color 0.2s',
            }}
            onMouseEnter={e => { e.currentTarget.style.color = '#8B3535'; }}
            onMouseLeave={e => { e.currentTarget.style.color = '#C4A8A8'; }}
          >
            delete
          </button>
        </div>
      </div>
    </motion.article>
  );
}

/* ── MAIN PAGE ────────────────────────────────────────────── */
export default function AllEntries() {
  const [entries,     setEntries]     = useState([]);
  const [total,       setTotal]       = useState(0);
  const [page,        setPage]        = useState(1);
  const [loading,     setLoading]     = useState(true);
  const [search,      setSearch]      = useState('');
  const [filterMood,  setFilterMood]  = useState('');
  const [filterFav,   setFilterFav]   = useState(false);
  const [showFilters, setShowFilters] = useState(false);

  // useSearchParams allows us to read ?favorite=true from the URL
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const LIMIT = 12;

  // ── BUG-03 FIX ──────────────────────────────────────────
  // BEFORE: useEffect(fn, [])  — ran only once on first mount.
  //   Clicking the Sidebar "Favorites" link when already on
  //   /entries never unmounts the component, so the effect
  //   never re-ran and filterFav stayed false.
  // AFTER:  useEffect(fn, [searchParams]) — re-runs whenever
  //   the URL query params change, even on the same route.
  // ────────────────────────────────────────────────────────
  useEffect(() => {
    const isFavRoute = searchParams.get('favorite') === 'true';
    setFilterFav(isFavRoute);
    setPage(1); // reset pagination when navigating to favorites
  }, [searchParams]);

  // Re-fetch whenever page, search, mood filter, or fav filter changes
  useEffect(() => {
    fetchEntries();
  }, [page, search, filterMood, filterFav]); // eslint-disable-line

  const fetchEntries = async () => {
    setLoading(true);
    try {
      const params = { page, limit: LIMIT };
      if (search)    params.search   = search;
      if (filterMood) params.mood    = filterMood;
      if (filterFav)  params.favorite = 'true';
      const { data } = await axios.get('/api/entries', { params });
      setEntries(data.entries || []);
      setTotal(data.total   || 0);
    } catch (err) {
      console.error('Failed to fetch entries:', err);
    }
    setLoading(false);
  };

  // ── BUG-08 FIX: also decrement total so count stays accurate
  const handleDelete = (id) => {
    setEntries(prev => prev.filter(e => e.id !== id));
    setTotal(prev => Math.max(0, prev - 1));
  };

  // ── BUG-07 FIX: flip is_favorite in local state immediately
  // so the heart icon updates without a full re-fetch.
  const handleFavorite = (id, newIsFavorite) => {
    setEntries(prev =>
      prev.map(e => e.id === id ? { ...e, is_favorite: newIsFavorite ? 1 : 0 } : e)
    );
    // If we are on the favorites view and the entry was un-favorited, remove it
    if (filterFav && !newIsFavorite) {
      setEntries(prev => prev.filter(e => e.id !== id));
      setTotal(prev => Math.max(0, prev - 1));
    }
  };

  const clearFilters = () => {
    setSearch('');
    setFilterMood('');
    setFilterFav(false);
    setPage(1);
  };

  const hasFilters = search || filterMood || filterFav;

  return (
    <AppLayout>
      {/* ── Header ──────────────────────────────────────── */}
      <motion.div initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }} style={{ marginBottom: 28 }}>
        <div style={{ display: 'flex', alignItems: 'flex-end', justifyContent: 'space-between', marginBottom: 20 }}>
          <div>
            <div style={{ fontFamily: "'Cormorant Garamond', serif", fontStyle: 'italic', fontSize: '0.95rem', color: 'var(--ink-muted)', marginBottom: 4 }}>
              {filterFav ? 'Your favourites' : 'Your collection'}
            </div>
            <div style={{ fontFamily: "'Playfair Display', serif", fontWeight: 700, fontSize: '1.9rem', color: 'var(--ink)', lineHeight: 1 }}>
              {filterFav ? 'Favorites' : 'All Memories'}
            </div>
          </div>
          <div style={{ display: 'flex', gap: 10 }}>
            <button
              onClick={() => setShowFilters(f => !f)}
              style={{
                display: 'flex', alignItems: 'center', gap: 6, padding: '9px 16px',
                background: showFilters ? 'var(--parchment)' : 'var(--cream-light)',
                border: '1px solid rgba(212,201,184,0.6)', borderRadius: 8,
                fontFamily: "'DM Sans', sans-serif", fontSize: 13,
                color: 'var(--ink-light)', cursor: 'pointer',
              }}
            >
              <SlidersHorizontal size={14} /> Filter
              {hasFilters && (
                <span style={{ width: 7, height: 7, borderRadius: '50%', background: 'var(--bark)', display: 'inline-block' }} />
              )}
            </button>
            <button
              onClick={() => navigate('/editor')}
              className="btn-primary"
              style={{ gap: 7, fontSize: 13, padding: '9px 18px' }}
            >
              <PenSquare size={14} /> New Entry
            </button>
          </div>
        </div>

        {/* Search */}
        <div style={{ position: 'relative' }}>
          <Search size={15} style={{ position: 'absolute', left: 14, top: '50%', transform: 'translateY(-50%)', color: '#B8A99A' }} />
          <input
            value={search}
            onChange={e => { setSearch(e.target.value); setPage(1); }}
            placeholder="Search your memories..."
            style={{
              width: '100%', padding: '11px 14px 11px 40px',
              background: 'var(--cream-light)', border: '1.5px solid rgba(212,201,184,0.6)',
              borderRadius: 10, fontFamily: "'DM Sans', sans-serif", fontSize: 14,
              color: 'var(--ink)', outline: 'none', transition: 'border-color 0.2s',
            }}
            onFocus={e => { e.target.style.borderColor = 'var(--bark-light)'; }}
            onBlur={e =>  { e.target.style.borderColor = 'rgba(212,201,184,0.6)'; }}
          />
          {search && (
            <button
              onClick={() => setSearch('')}
              style={{ position: 'absolute', right: 12, top: '50%', transform: 'translateY(-50%)',
                background: 'none', border: 'none', cursor: 'pointer', color: '#B8A99A', display: 'flex' }}>
              <X size={14} />
            </button>
          )}
        </div>
      </motion.div>

      {/* ── Filter panel ────────────────────────────────── */}
      <AnimatePresence>
        {showFilters && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            style={{ overflow: 'hidden', marginBottom: 20 }}
          >
            <div style={{ background: 'var(--cream-light)', border: '1px solid rgba(212,201,184,0.5)', borderRadius: 10, padding: '18px 20px' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 10, flexWrap: 'wrap' }}>
                <span style={{ fontFamily: "'DM Sans', sans-serif", fontSize: 12, fontWeight: 500, color: 'var(--ink-light)', letterSpacing: '0.06em', textTransform: 'uppercase' }}>
                  Mood:
                </span>
                {MOOD_LIST.map(m => (
                  <button
                    key={m}
                    onClick={() => { setFilterMood(filterMood === m ? '' : m); setPage(1); }}
                    style={{
                      padding: '4px 12px', borderRadius: 20, border: 'none', cursor: 'pointer',
                      fontFamily: "'DM Sans', sans-serif", fontSize: 12, fontWeight: 500,
                      background: filterMood === m ? MOODS[m].color : 'var(--parchment)',
                      color:      filterMood === m ? MOODS[m].text  : 'var(--ink-light)',
                      transition: 'all 0.15s',
                    }}
                  >
                    {MOODS[m].emoji} {m}
                  </button>
                ))}

                <div style={{ width: 1, height: 20, background: 'rgba(212,201,184,0.6)' }} />

                <button
                  onClick={() => { setFilterFav(f => !f); setPage(1); }}
                  style={{
                    display: 'flex', alignItems: 'center', gap: 5,
                    padding: '4px 12px', borderRadius: 20, border: 'none', cursor: 'pointer',
                    fontFamily: "'DM Sans', sans-serif", fontSize: 12,
                    background: filterFav ? '#F5E8E8' : 'var(--parchment)',
                    color:      filterFav ? '#8B3535' : 'var(--ink-light)',
                    transition: 'all 0.15s',
                  }}
                >
                  <Heart size={12} fill={filterFav ? '#C4826A' : 'none'} color={filterFav ? '#C4826A' : 'currentColor'} />
                  Favorites
                </button>

                {hasFilters && (
                  <button
                    onClick={clearFilters}
                    style={{
                      display: 'flex', alignItems: 'center', gap: 4, padding: '4px 12px', borderRadius: 20,
                      border: '1px dashed rgba(212,201,184,0.8)', background: 'transparent', cursor: 'pointer',
                      fontFamily: "'DM Sans', sans-serif", fontSize: 11, color: 'var(--ink-muted)',
                    }}
                  >
                    <X size={11} /> Clear
                  </button>
                )}
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* ── Entry count ─────────────────────────────────── */}
      <div style={{ fontFamily: "'DM Sans', sans-serif", fontSize: 12, color: 'var(--ink-muted)', marginBottom: 18 }}>
        {total} {total === 1 ? 'memory' : 'memories'}{hasFilters ? ' found' : ''}
      </div>

      {/* ── Grid ────────────────────────────────────────── */}
      {loading ? (
        <div style={{ display: 'flex', justifyContent: 'center', padding: '60px 0' }}>
          <div style={{ fontFamily: "'Cormorant Garamond', serif", fontStyle: 'italic', color: 'var(--ink-muted)', fontSize: '1.1rem' }}>
            Gathering your memories...
          </div>
        </div>
      ) : entries.length === 0 ? (
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }}
          style={{ textAlign: 'center', padding: '80px 0' }}>
          <div style={{ fontSize: 48, marginBottom: 16, opacity: 0.4 }}>
            {filterFav ? '🤍' : '📖'}
          </div>
          <div style={{ fontFamily: "'Cormorant Garamond', serif", fontStyle: 'italic', fontSize: '1.3rem', color: 'var(--ink-muted)', marginBottom: 16 }}>
            {filterFav
              ? 'No favorites yet. Heart an entry to see it here.'
              : hasFilters
                ? 'No entries match your search.'
                : 'Your diary is empty — begin your first story.'}
          </div>
          {!hasFilters && !filterFav && (
            <button onClick={() => navigate('/editor')} className="btn-primary" style={{ fontSize: 13 }}>
              Write your first entry
            </button>
          )}
        </motion.div>
      ) : (
        <motion.div
          variants={stagger} initial="hidden" animate="show"
          style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(280px, 1fr))', gap: 18 }}
        >
          {entries.map(e => (
            <EntryCard
              key={e.id}
              entry={e}
              onDelete={handleDelete}
              onFavorite={handleFavorite}
            />
          ))}
        </motion.div>
      )}

      {/* ── Pagination ──────────────────────────────────── */}
      {total > LIMIT && (
        <div style={{ display: 'flex', justifyContent: 'center', gap: 8, marginTop: 40 }}>
          {Array.from({ length: Math.ceil(total / LIMIT) }, (_, i) => (
            <button
              key={i}
              onClick={() => setPage(i + 1)}
              style={{
                width: 36, height: 36, borderRadius: 8,
                border: '1px solid rgba(212,201,184,0.6)',
                background: page === i + 1 ? 'var(--ink)' : 'var(--cream-light)',
                color:      page === i + 1 ? 'var(--cream)' : 'var(--ink-light)',
                fontFamily: "'DM Sans', sans-serif", fontSize: 13, cursor: 'pointer',
                transition: 'all 0.2s',
              }}
            >
              {i + 1}
            </button>
          ))}
        </div>
      )}
    </AppLayout>
  );
}
