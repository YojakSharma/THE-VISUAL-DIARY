import React from 'react';
import { NavLink, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { LayoutDashboard, BookOpen, Calendar, Star, Tag, BarChart2, Settings, LogOut, PenSquare } from 'lucide-react';
import { useAuth } from '../context/AuthContext';

const NAV = [
  { to: '/dashboard', icon: LayoutDashboard, label: 'Dashboard' },
  { to: '/entries',   icon: BookOpen,        label: 'All Entries' },
  { to: '/calendar',  icon: Calendar,        label: 'Calendar' },
  { to: '/entries?favorite=true', icon: Star, label: 'Favorites' },
  { to: '/settings',  icon: Settings,        label: 'Settings' },
];

export default function Sidebar() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();

  const handleLogout = () => { logout(); navigate('/'); };

  const quotes = [
    'The pages you write today become the memories of tomorrow.',
    'Write without fear. Edit without mercy.',
    'A journal is your own private world.',
    'Words are how we think. Stories are how we live.',
  ];
  const quote = quotes[Math.floor(new Date().getDate() % quotes.length)];

  return (
    <motion.aside
      initial={{ x: -20, opacity: 0 }} animate={{ x: 0, opacity: 1 }}
      transition={{ duration: 0.4 }}
      style={{
        width: 220, minHeight: '100vh', flexShrink: 0,
        background: 'var(--cream)', borderRight: '1px solid rgba(212,201,184,0.5)',
        display: 'flex', flexDirection: 'column', padding: '24px 14px',
        position: 'sticky', top: 0, height: '100vh', overflowY: 'auto',
      }}
    >
      {/* Logo */}
      <NavLink to="/dashboard" style={{ textDecoration: 'none', marginBottom: 28, display: 'block', paddingLeft: 6 }}>
        <div style={{ fontFamily: "'Playfair Display', serif", fontWeight: 900, fontSize: 16, color: 'var(--ink)', lineHeight: 1.15, letterSpacing: '-0.01em' }}>
          THE<br/>VISUAL<br/>DIARY
        </div>
      </NavLink>

      {/* User */}
      <NavLink to="/profile" style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '10px 10px', borderRadius: 10, marginBottom: 20, textDecoration: 'none', background: 'rgba(232,224,208,0.4)', transition: 'background 0.2s' }}>
        <div style={{
          width: 36, height: 36, borderRadius: '50%', overflow: 'hidden',
          background: 'linear-gradient(135deg,#C4A882,#8B7355)',
          border: '2px solid rgba(196,168,130,0.5)',
          flexShrink: 0, display: 'flex', alignItems: 'center', justifyContent: 'center',
        }}>
          {user?.profile_image
            ? <img src={`http://localhost:5000${user.profile_image}`} alt="" style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
            : <span style={{ fontFamily: "'Playfair Display', serif", fontWeight: 700, fontSize: 14, color: 'white' }}>
                {(user?.display_name || user?.username || 'U')[0].toUpperCase()}
              </span>
          }
        </div>
        <div style={{ overflow: 'hidden' }}>
          <div style={{ fontFamily: "'DM Sans', sans-serif", fontSize: 11, color: 'var(--ink-muted)', marginBottom: 1 }}>Welcome back,</div>
          <div style={{ fontFamily: "'Cormorant Garamond', serif", fontStyle: 'italic', fontSize: '1rem', color: 'var(--ink)', fontWeight: 500, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>
            {user?.display_name || user?.username}
          </div>
        </div>
      </NavLink>

      {/* New Entry CTA */}
      <NavLink to="/editor" style={{ textDecoration: 'none', marginBottom: 20 }}>
        <motion.div whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }}
          style={{
            display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 7,
            padding: '10px', background: 'var(--ink)', color: 'var(--cream)',
            borderRadius: 9, fontFamily: "'DM Sans', sans-serif", fontSize: 13, fontWeight: 500, cursor: 'pointer',
          }}>
          <PenSquare size={14} /> New Entry
        </motion.div>
      </NavLink>

      {/* Nav links */}
      <nav style={{ display: 'flex', flexDirection: 'column', gap: 2, flex: 1 }}>
        {NAV.map(({ to, icon: Icon, label }) => (
          <NavLink key={to} to={to} style={{ textDecoration: 'none' }}
            className={({ isActive }) => `sidebar-link ${isActive ? 'active' : ''}`}>
            <Icon size={16} />
            {label}
          </NavLink>
        ))}
        <div style={{ height: 1, background: 'rgba(212,201,184,0.5)', margin: '10px 6px' }} />
        <button onClick={handleLogout} className="sidebar-link"
          style={{ background: 'none', border: 'none', cursor: 'pointer', width: '100%', textAlign: 'left' }}>
          <LogOut size={16} /> Log Out
        </button>
      </nav>

      {/* Inspirational quote */}
      <motion.div
        initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.5 }}
        style={{
          marginTop: 20, background: 'var(--cream-dark)', borderRadius: 10, padding: '14px 14px',
          position: 'relative', overflow: 'visible',
        }}>
        {/* Botanical deco */}
        <div style={{ position: 'absolute', bottom: 0, right: 8, fontSize: 32, opacity: 0.3 }}>🌿</div>
        <div style={{ fontFamily: "'Caveat', cursive", fontSize: 14, color: 'var(--ink-light)', lineHeight: 1.55, paddingRight: 24, position: 'relative', zIndex: 1 }}>
          "{quote}"
        </div>
      </motion.div>
    </motion.aside>
  );
}
