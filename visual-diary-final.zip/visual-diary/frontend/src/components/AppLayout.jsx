import React from 'react';
import Sidebar from './Sidebar';

export default function AppLayout({ children }) {
  return (
    <div style={{ display: 'flex', minHeight: '100vh', background: 'var(--cream)' }}>
      <Sidebar />
      <main style={{ flex: 1, overflowY: 'auto', padding: '32px 36px', maxWidth: 'calc(100vw - 220px)' }}>
        {children}
      </main>
    </div>
  );
}
