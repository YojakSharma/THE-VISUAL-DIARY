import React, { createContext, useContext, useState, useEffect } from 'react';
import axios from 'axios';
import { applyTheme } from '../utils/theme';

const AuthContext = createContext();

const DEFAULT_SETTINGS = {
  theme:                 'vintage-paper',
  font_size:             'medium',
  notifications_enabled: true,
  auto_save_interval:    30,
  public_profile:        false,
};

export const AuthProvider = ({ children }) => {
  const [user,     setUser]     = useState(null);
  const [settings, setSettings] = useState(DEFAULT_SETTINGS);
  const [loading,  setLoading]  = useState(true);

  // ─── BUG-04 + BUG-05 FIX ────────────────────────────────────
  // Previously: settings were only fetched when the Settings page
  //   mounted. applyTheme() was never called. Theme + font changes
  //   had zero visual effect.
  // Fix: fetch /api/settings right after any auth confirmation and
  //   call applyTheme() immediately with the saved values.
  // ─────────────────────────────────────────────────────────────
  const loadAndApplySettings = async () => {
    try {
      const { data } = await axios.get('/api/settings');
      if (data && data.settings) {
        const s = data.settings;
        setSettings(prev => ({ ...prev, ...s }));
        applyTheme(
          s.theme     || DEFAULT_SETTINGS.theme,
          s.font_size || DEFAULT_SETTINGS.font_size
        );
        return s;
      }
    } catch {
      // Network or auth failure — apply defaults so UI stays consistent
      applyTheme(DEFAULT_SETTINGS.theme, DEFAULT_SETTINGS.font_size);
    }
    return null;
  };

  // Restore session from localStorage token on every page load
  useEffect(() => {
    const token = localStorage.getItem('vd_token');
    if (token) {
      axios.defaults.headers.common['Authorization'] = `Bearer ${token}`;
      axios.get('/api/auth/me')
        .then(res => {
          setUser(res.data.user);
          return loadAndApplySettings(); // apply saved theme/font immediately
        })
        .catch(() => {
          localStorage.removeItem('vd_token');
          delete axios.defaults.headers.common['Authorization'];
          applyTheme(DEFAULT_SETTINGS.theme, DEFAULT_SETTINGS.font_size);
        })
        .finally(() => setLoading(false));
    } else {
      setLoading(false);
    }
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  const login = async (email, password) => {
    const res = await axios.post('/api/auth/login', { email, password });
    const { token, user } = res.data;
    localStorage.setItem('vd_token', token);
    axios.defaults.headers.common['Authorization'] = `Bearer ${token}`;
    setUser(user);
    await loadAndApplySettings(); // apply theme right after login
    return user;
  };

  const signup = async (data) => {
    const res = await axios.post('/api/auth/signup', data);
    const { token, user } = res.data;
    localStorage.setItem('vd_token', token);
    axios.defaults.headers.common['Authorization'] = `Bearer ${token}`;
    setUser(user);
    await loadAndApplySettings();
    return user;
  };

  const logout = () => {
    localStorage.removeItem('vd_token');
    delete axios.defaults.headers.common['Authorization'];
    setUser(null);
    setSettings(DEFAULT_SETTINGS);
    applyTheme(DEFAULT_SETTINGS.theme, DEFAULT_SETTINGS.font_size); // reset on logout
  };

  const updateUser = (updates) => setUser(prev => ({ ...prev, ...updates }));

  const updateSettings = (updates) => {
    setSettings(prev => {
      const next = { ...prev, ...updates };
      // If theme or font_size changed, apply immediately
      if (updates.theme !== undefined || updates.font_size !== undefined) {
        applyTheme(next.theme, next.font_size);
      }
      return next;
    });
  };

  return (
    <AuthContext.Provider value={{
      user, loading, settings,
      login, signup, logout,
      updateUser, updateSettings, loadAndApplySettings,
    }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => useContext(AuthContext);
