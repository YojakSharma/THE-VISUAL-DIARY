# 📖 THE VISUAL DIARY
### *A quiet space for thoughts, memories, and moments.*

A luxury digital scrapbook journal — built with React, Node.js, Express, MySQL, Tailwind CSS, and Framer Motion.

---

## ✦ Stack

| Layer     | Technology                             |
|-----------|----------------------------------------|
| Frontend  | React 18, Tailwind CSS 3, Framer Motion |
| Backend   | Node.js v14, Express.js                |
| Database  | MySQL                                  |
| Auth      | JWT + bcryptjs                         |
| Uploads   | Multer (local file storage)            |
| Fonts     | Playfair Display, Cormorant Garamond, Caveat, DM Sans |

---

## ✦ Project Structure

```
visual-diary/
├── backend/
│   ├── server.js              # Express entry point
│   ├── .env.example           # Environment variables template
│   ├── package.json
│   ├── config/
│   │   └── db.js              # MySQL connection pool
│   ├── middleware/
│   │   └── auth.js            # JWT middleware
│   ├── routes/
│   │   ├── auth.js            # signup / login / me
│   │   ├── entries.js         # CRUD + stats + calendar
│   │   ├── profile.js         # profile + image upload
│   │   └── settings.js        # user settings + themes
│   ├── uploads/               # uploaded images (auto-created)
│   └── database/
│       └── schema.sql         # Full MySQL schema
│
└── frontend/
    ├── package.json
    ├── tailwind.config.js
    ├── postcss.config.js
    ├── public/
    │   └── index.html         # Google Fonts loaded here
    └── src/
        ├── index.js
        ├── App.jsx            # Routes
        ├── index.css          # All custom CSS (textures, polaroids, tape, etc.)
        ├── context/
        │   └── AuthContext.jsx
        ├── components/
        │   ├── AppLayout.jsx  # Sidebar + main wrapper
        │   └── Sidebar.jsx
        └── pages/
            ├── Landing.jsx    # Cinematic editorial landing
            ├── Login.jsx
            ├── Signup.jsx
            ├── Dashboard.jsx  # Aesthetic non-corporate overview
            ├── Editor.jsx     # ✦ THE HEART — visual journal editor
            ├── AllEntries.jsx # Card grid with search & filters
            ├── Calendar.jsx   # Monthly memory calendar
            ├── Profile.jsx    # Beautiful profile + gallery
            └── Settings.jsx   # Themes, preferences, password
```

---

## ✦ Setup Instructions

### 1. Prerequisites

- Node.js v14.21.3
- MySQL 8.x
- npm or yarn

### 2. Database Setup

Open MySQL and run the schema:

```sql
-- In MySQL shell or Workbench:
source /path/to/visual-diary/backend/database/schema.sql
```

Or run directly:
```bash
mysql -u root -p < backend/database/schema.sql
```

### 3. Backend Setup

```bash
cd visual-diary/backend

# Install dependencies
npm install

# Create .env file
cp .env.example .env
```

Edit `.env`:
```
PORT=5000
CLIENT_URL=http://localhost:3000
DB_HOST=localhost
DB_USER=root
DB_PASSWORD=your_mysql_password
DB_NAME=visual_diary
JWT_SECRET=your_secret_key_here
```

Create the uploads folder:
```bash
mkdir -p uploads
```

Start the backend:
```bash
# Development
npm run dev

# Production
npm start
```

✅ Backend runs on **http://localhost:5000**

### 4. Frontend Setup

```bash
cd visual-diary/frontend

# Install dependencies
npm install

# Start development server
npm start
```

✅ Frontend runs on **http://localhost:3000**

---

## ✦ Pages Overview

| Page       | Route           | Description                          |
|------------|-----------------|--------------------------------------|
| Landing    | `/`             | Cinematic editorial hero page        |
| Login      | `/login`        | Paper card login form                |
| Signup     | `/signup`       | Paper card signup form               |
| Dashboard  | `/dashboard`    | Stats, recent entries, mini calendar |
| Editor     | `/editor`       | Visual scrapbook journal editor      |
| Edit Entry | `/editor/:id`   | Edit an existing entry               |
| All Entries| `/entries`      | Card grid with search & mood filters |
| Calendar   | `/calendar`     | Monthly memory timeline              |
| Profile    | `/profile`      | Profile stats, gallery, bio          |
| Settings   | `/settings`     | Themes, preferences, password        |

---

## ✦ API Endpoints

### Auth
```
POST   /api/auth/signup     — Register new user
POST   /api/auth/login      — Login
GET    /api/auth/me         — Get current user (auth required)
```

### Entries
```
GET    /api/entries         — List entries (search, mood, favorite, pagination)
GET    /api/entries/stats   — User stats (count, streak, words, moods)
GET    /api/entries/calendar — Entries by month
GET    /api/entries/:id     — Single entry with tags & images
POST   /api/entries         — Create entry
PUT    /api/entries/:id     — Update entry
DELETE /api/entries/:id     — Delete entry
```

### Profile
```
GET    /api/profile         — Get profile + stats
PUT    /api/profile         — Update display_name, bio, username
PUT    /api/profile/password — Change password
POST   /api/profile/avatar  — Upload profile image
POST   /api/profile/upload-image — Upload journal image
```

### Settings
```
GET    /api/settings        — Get user settings
PUT    /api/settings        — Update settings
GET    /api/settings/themes — List available themes
```

---

## ✦ Design System

### Colors
```
--cream:         #F5F0E8   (main background)
--cream-light:   #FAF7F2   (paper/card background)
--parchment:     #E8E0D0   (borders, subtle bg)
--bark:          #8B7355   (warm brown accent)
--bark-light:    #C4A882   (lighter accent)
--ink:           #2C2420   (primary text)
--ink-light:     #5C4F44   (secondary text)
--ink-muted:     #9A8B7E   (muted/label text)
```

### Fonts
- **Playfair Display** — Large headings, logo
- **Cormorant Garamond** — Body text, journal writing
- **Caveat** — Handwritten labels, sticky notes
- **DM Sans** — UI elements, labels, navigation

### Special Effects
- 🟫 Paper grain texture (SVG filter overlay)
- 📌 Tape strips (CSS with diagonal texture)
- 📸 Polaroid frames (white padding + caption)
- 📒 Dotted / lined / grid paper modes
- 🌿 Floating botanical decorations
- ✨ Framer Motion fade-ups and hover elevations

---

## ✦ Features

- ✅ JWT authentication with persistent sessions
- ✅ bcrypt password hashing
- ✅ Create, edit, delete journal entries
- ✅ Rich mood tagging (8 moods)
- ✅ Custom tags with inline editor
- ✅ Image uploads (polaroid display)
- ✅ Auto-save (4-second debounce)
- ✅ Draft / Published toggle
- ✅ Favorites
- ✅ Paper mode: dotted / lined / grid / plain
- ✅ Monthly calendar with mood indicators
- ✅ Dashboard with stats + mini calendar
- ✅ Profile with memory gallery
- ✅ 5 aesthetic themes
- ✅ Search & filter entries
- ✅ Responsive design
- ✅ Smooth Framer Motion animations

---

## ✦ Notes

- Images are stored locally in `backend/uploads/`
- JWT tokens expire after 7 days
- Auto-save triggers 4 seconds after any change
- The `uploads` folder must exist before running the server

---

*"Write what should not be forgotten. Keep what matters. Let go of what doesn't."*
